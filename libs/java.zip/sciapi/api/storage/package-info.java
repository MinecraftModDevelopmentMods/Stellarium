/**
 * 
 */
/**
 * 
 * Useful Storage Classes!
 * 
 * @author Astros
 *
 */
package sciapi.api.storage;

package sciapi.api.pinterface.def;

import java.util.*;

import sciapi.api.pinterface.ICategory;
import sciapi.api.pinterface.ILogFilter;
import sciapi.api.pinterface.ILogger;
import sciapi.api.pinterface.IStrMessage;
import sciapi.api.pinterface.LogLevel;

public class LogManager implements ILogger {
	
	public class LogComp {
		public ILogger logger;
		public List<ILogFilter> filter;
		
		public LogComp(ILogger l)
		{
			logger = l;
			filter = new ArrayList();
		}
		
		public void addFilter(ILogFilter f)
		{
			filter.add(f);
		}
	}
	
	private Map<String, LogComp> logs = new HashMap();
	
	public void addLogger(String name, ILogger l)
	{
		if(logs.containsKey(name))
		{
			log(LogLevel.ERROR, DCException.reg,
					"Registration Exception occured.\n"
					+ "Attempted to register Logger with existing id.\n"
					+ "This Logger wont be registered, and The exception won't give any other effects");
			
			return;
		}
		
		logs.put(name, new LogComp(l));
	}
	
	public void addFilter(String name, ILogFilter f)
	{
		LogComp lc = logs.get(name);
		
		if(lc == null)
		{
			log(LogLevel.ERROR, DCException.reg,
					"Registration Exception occured.\n"
					+ "Attempted to add Log Filter to not-existing Logger.\n"
					+ "This Filter wont be added, and The exception won't give any other effects");
			
			return;
		}
		
		lc.filter.add(f);
	}
	
	public void removeFilter(String name, ILogFilter f)
	{
		LogComp lc = logs.get(name);
		
		if(lc == null)
		{
			log(LogLevel.ERROR, DCException.reg,
					"Registration Exception occured.\n"
					+ "Attempted to remove Log Filter from not-existing Logger.\n"
					+ "This Filter wont be removed, and The exception won't give any other effects");
			
			return;
		}
		
		if(!lc.filter.contains(f))
		{
			log(LogLevel.INFO, SciAPIInfo.ins, "Attempted to remove non-existing filter.");
			
			return;
		}
		
		lc.filter.remove(f);
	}
	
	@Override
	public void log(LogLevel lev, ICategory ca, String con) {
		for(LogComp lc : logs.values())
		{
			for(ILogFilter f : lc.filter)
			{
				if(!f.filter(lev, ca))
					break;
			}
			
			lc.logger.log(lev, ca, con);
		}
	}

	@Override
	public void log(LogLevel lev, ICategory ca, IStrMessage msg) {
		for(LogComp lc : logs.values())
		{
			for(ILogFilter f : lc.filter)
			{
				if(!f.filter(lev, ca))
					break;
			}
			
			lc.logger.log(lev, ca, msg);
		}
	}

}

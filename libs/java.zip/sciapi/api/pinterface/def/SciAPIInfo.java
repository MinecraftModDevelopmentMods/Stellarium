package sciapi.api.pinterface.def;

import sciapi.api.pinterface.ICategory;

public class SciAPIInfo implements ICategory {

	public static SciAPIInfo ins = new SciAPIInfo();
	
	@Override
	public String getName() {
		return "SciAPI.Info";
	}

	@Override
	public ICategory getParent() {
		return null;
	}

}

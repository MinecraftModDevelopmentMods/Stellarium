/**
 * 
 */
/**
 * 
 * Default PInterfaces for SciAPI project.
 * 
 * @author Astros
 *
 */
package sciapi.api.pinterface.def;
package sciapi.api.pinterface.def;

import sciapi.api.pinterface.ICategory;

public class ProfilerCategory implements ICategory {

	public static ProfilerCategory base = new ProfilerCategory(null, "SciAPI.Profiling");
	public static ProfilerCategory pooling = new ProfilerCategory(base, "Pooling");
	
	
	private ProfilerCategory par;
	private String name;
	
	public ProfilerCategory(ProfilerCategory ppar, String pname)
	{
		par = ppar;
		name = pname;
	}
	
	@Override
	public String getName() {
		if(par != null)
			return par.getName() + "." + name;
		
		return name;
	}

	@Override
	public ICategory getParent() {
		return par;
	}

}

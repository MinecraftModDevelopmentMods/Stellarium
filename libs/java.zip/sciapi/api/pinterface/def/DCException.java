package sciapi.api.pinterface.def;

import sciapi.api.pinterface.ICategory;

public class DCException implements ICategory {

	public static DCException common = new DCException(null, "Common");
	public static DCException exc = new DCException(null, "SciAPI");
	public static DCException reg = new DCException(exc, "Registration");
	public static DCException calc = new DCException(exc, "Calculation");
	
	private DCException par;
	private String name;
	
	public DCException(DCException ppar, String pname)
	{
		par = ppar;
		name = pname;
	}
	
	@Override
	public ICategory getParent() {
		return par;
	}

	@Override
	public String getName() {
		if(par == null)
			return name;
		return par.getName() + "." + name;
	}
	
	
	public static DCException getRegException(String name)
	{
		return new DCException(reg, name);
	}
	
	public static DCException getCalcException(String name)
	{
		return new DCException(calc, name);
	}

}

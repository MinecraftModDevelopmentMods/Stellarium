package sciapi.api.pinterface.def;

import sciapi.api.pinterface.LogLevel;
import sciapi.api.registry.PInterface;

public class CommonExcLog {
	
	/**Logs Severe Exception*/
	public static RuntimeException logSevere(RuntimeException e)
	{
		PInterface.getLogger().log(LogLevel.SEVERE, DCException.common, e.getMessage());
		return e;
	}
	
	/**Logs Exception(Not Severe, related with wrong usage)*/
	public static RuntimeException logError(RuntimeException e)
	{
		PInterface.getLogger().log(LogLevel.ERROR, DCException.common, e.getMessage());
		return e;
	}
	
}

package sciapi.api.pinterface.def;

import sciapi.api.pinterface.ICategory;
import sciapi.api.pinterface.ILogFilter;
import sciapi.api.pinterface.LogLevel;

public class SciLogFilter implements ILogFilter {

	public boolean debugEnabled, poolingEnabled;
	
	@Override
	public boolean filter(LogLevel lev, ICategory ca) {
		if(lev == LogLevel.DEBUG)
		{
			return debugEnabled;
		}
		
		if(ca instanceof ProfilerCategory)
		{
			if(ca == ProfilerCategory.pooling)
			{
				if(poolingEnabled)
					return true;
				return false;
			}
		}
		
		return true;
	}

}

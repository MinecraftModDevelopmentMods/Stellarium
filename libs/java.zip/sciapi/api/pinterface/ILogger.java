package sciapi.api.pinterface;

/**
 * Logger Interface for Logging control.
 * */
public interface ILogger {

	/**
	 * Logs simple string.
	 * @param lev logging level
	 * @param ca the category
	 * @param con the context
	 * */
	public void log(LogLevel lev, ICategory ca, String con);
	
	/**
	 * Logs string message.
	 * @param lev logging level
	 * @param ca the category
	 * @param msg the message to be logged
	 * */
	public void log(LogLevel lev, ICategory ca, IStrMessage msg);
}

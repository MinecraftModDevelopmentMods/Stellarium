package sciapi.api.pinterface;

/**Category Interface to identify the categories.*/
public interface ICategory {

	/**Gives the name of the Category.*/
	public String getName();
	
	/**Gives Parent Category. This can be null*/
	public ICategory getParent();
	
}

/**
 * 
 */
/**
 * 
 * Contains Interfaces for Communication with Several Types of Project.
 * 
 * @author Astros
 *
 */
package sciapi.api.pinterface;
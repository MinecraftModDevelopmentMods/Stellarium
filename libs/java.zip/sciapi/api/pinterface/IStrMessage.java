package sciapi.api.pinterface;

public interface IStrMessage {
	
	/**Gives the Context of this message.*/
	public String getContext();
	
}

package sciapi.api.pinterface;

public interface ILogFilter {

	/**
	 * Filters log via category.
	 * @param lev logging level
	 * @param ca the category
	 * @return <code>true</code> if filter test is passed.
	 * */
	public boolean filter(LogLevel lev, ICategory ca);
	
}

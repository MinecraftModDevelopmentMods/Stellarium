package sciapi.api.pinterface;

public enum LogLevel {
	INFO("Info"),
	DEBUG("Debug"),
	WARNING("Warning"),
	ERROR("Error"),
	SEVERE("Severe");
	
	private String desc;
	
	LogLevel(String pdesc)
	{
		desc = pdesc;
	}
	
	public String getLevelName()
	{
		return desc;
	}
}

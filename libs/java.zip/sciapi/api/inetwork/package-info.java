/**
 * 
 */
/**
 * 
 * Interactive Network API for Minecraft.
 * Can be used for electricity system, telecommunication system, and so on.
 * 
 * @author Astros
 *
 */
package sciapi.api.inetwork;
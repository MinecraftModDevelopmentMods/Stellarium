package sciapi.api.inetwork.channel;

import sciapi.api.inetwork.IINetwork;

public interface IIChannelNetwork extends IINetwork {

}

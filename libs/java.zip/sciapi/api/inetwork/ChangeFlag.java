package sciapi.api.inetwork;

public enum ChangeFlag {
	ADDED,
	REMOVED,
	CHANGED
}

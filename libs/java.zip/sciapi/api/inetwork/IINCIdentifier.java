package sciapi.api.inetwork;

public interface IINCIdentifier {

}

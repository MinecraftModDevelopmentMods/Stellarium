package sciapi.api.unit;

import scala.reflect.internal.Trees.If;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;

public class MOp {
	
	public static IGroupOperator<Measurement> mult = new IGroupOperator<Measurement>() {

		@Override
		public IValRef<Measurement> calc(IValRef<Measurement> par1,
				IValRef<Measurement> par2) {
			MTempRef p = UnitCalc.temporize(par1);
			MTempRef ret = UnitCalc.temporize(par2);
			
			ret.setDim(p.getDim().mult(ret.getDim()));
			ret.setDVal(p.getDVal() * ret.getDVal());

			p.onUsed();
			
			return ret;
		}

		@Override
		public IValRef<Measurement> identity() {
			return UnitCalc.one;
		}

		@Override
		public IValRef<Measurement> inverse(IValRef<Measurement> par) {
			MTempRef ret = UnitCalc.temporize(par);
			
			ret.setDim(UnitCalc.angle.div(ret.getDim()));
			ret.setDVal(1.0 / ret.getDVal());
			
			return ret;
		}
		
	};
	
	public static IBiOperator<Measurement, Measurement, Measurement> div = new IBiOperator<Measurement, Measurement, Measurement>() {

		@Override
		public IValRef<Measurement> calc(IValRef<Measurement> par1,
				IValRef<Measurement> par2) {
			MTempRef p = UnitCalc.temporize(par1);
			MTempRef ret = UnitCalc.temporize(par2);
			
			ret.setDim(p.getDim().div(ret.getDim()));
			ret.setDVal(p.getDVal() / ret.getDVal());

			p.onUsed();
			
			return ret;
		}
		
	};
}

package sciapi.api.unit;

import sciapi.api.abstraction.util.IProviderBase;
import sciapi.api.temporaries.TempUtil;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValSet;
import sciapi.api.value.STempRef;

public class MTempProvider implements IProviderBase<MTempRef> {

	private TempUtil<MTempRef> temprov;
	
	public MTempProvider()
	{
		temprov = new TempUtil<MTempRef>(this);
	}
	
	@Override
	public MTempRef getNew() {
		return new MTempRef();
	}
	
	@Temporal
	public MTempRef getTemp() {
		return temprov.getTemp();
	}
	
	public void release(MTempRef tmp) {
		temprov.release(tmp);
	}

}

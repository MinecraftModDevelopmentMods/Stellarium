package sciapi.api.unit;

import sciapi.api.basis.math.BMath;
import sciapi.api.unit.UnitDictionary.MInfo;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.numerics.IReal;

/**
 * Abstract Class for Measurement.
 * */
public abstract class Measurement implements IReal {
	
	private double value;
	protected String curunit;
	
	/**
	 * Get Name of this Measurement.
	 * Must be Constant.
	 * */
	abstract protected String getMeasurementName();
	
	@Deprecated
	public Measurement() {}
	
	/**
	 * Get Measurement in Standard Unit.
	 * */
	public Measurement(double pvalue){
		value = pvalue;
		curunit = getMeasurement().stduname;
	}
	
	/**
	 * Get Measurement with Unit.
	 * */
	public Measurement(double pvalue, String unitname){
		this(pvalue);
		curunit = unitname;
	}
	
	
	protected UnitDictionary.MInfo getMeasurement(){
		return UnitDictionary.instance().getMeasurement(this.getMeasurementName());
	}
	
	
	public String getUnit()
	{
		return this.curunit;
	}
	
	public Measurement setUnit(String pcurunit)
	{
		MInfo mi = getMeasurement();
		this.value = mi.fromStandard(mi.toStandard(value, curunit), pcurunit);
		this.curunit = pcurunit;
		
		return this;
	}
	
	public Measurement setStd()
	{
		MInfo mi = getMeasurement();
		this.value = mi.toStandard(value, curunit);
		this.curunit = mi.stduname;
		
		return this;
	}
	
	@Override
	public double asDouble() {
		return value;
	}

	@Override
	public float asFloat() {
		return (float)value;
	}
	
	public boolean equalMeasurement(Measurement m){
		return m.getMeasurementName().equals(getMeasurementName());
	}
	
	@Override
	public boolean equals(Object o){
		Measurement m = (Measurement) o;

		if(this.equalMeasurement(m)){
			return BMath.isSame(this.value, m.value);
		}
		else throw new MeasurementException(this, m, "equals");
	}

	@Override
	public void set(double v) {
		value = v;
	}

	@Override
	public void set(float v) {
		value = v;
	}

	@Override
	public IValSet getParentSet() {
		return this.getMeasurement().parset;
	}

	@Override
	public void onUsed() {
		//Does nothing
	}

	@Override
	public IValue getVal() {
		return this;
	}

	@Override
	public Measurement set(IValRef val) {
		val.onUsed();
		if(val.getVal() instanceof IReal)
		{
			if(val.getVal() instanceof Measurement)
			{
				MInfo mi = getMeasurement();
				Measurement thev = (Measurement) val.getVal();
				this.value = mi.fromStandard(mi.toStandard(thev.value, thev.curunit), curunit);
			}
			
			else this.value = ((IReal)val.getVal()).asDouble();
		}
		else if(val instanceof MTempRef)
		{
			
		}
		
		val.onUsed();
		
		return this;
	}
}
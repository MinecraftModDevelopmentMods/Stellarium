package sciapi.api.unit;

import java.util.*;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.unit.UnitDictionary.InterMDimension;
import sciapi.api.unit.UnitDictionary.MInfo;
import sciapi.api.value.IValRef;

public class UnitCalc {
	
	protected static List<String> basestds;
	//Ratio for std unit to SI unit.
	protected static List<Double> stdval = new ArrayList();
	//Inverse Ratio
	protected static List<Double> invstd = new ArrayList();
	
	protected static String anglemode;
	protected static boolean ratemode;
	
	private static UnitDictionary ins = UnitDictionary.instance();
	public static Measurement one;
	
	//For testing angle
	protected static InterMDimension angle;
	
	public static void Init()
	{
		one = ins.getNew(ins.getMeasurement(new MDimension()));
		
		basestds = ins.basemmap;
		
		for(int i = 0; i < basestds.size(); i++)
		{
			stdval.add(1.0);
			invstd.add(1.0);
		}
		
		angle = ins.new InterMDimension(new MDimension());
	}
		
	public static double getStdVal(Measurement m)
	{		
		return getStdVal(m.getMeasurement(), m.curunit) * m.asDouble();
	}
	
	public static void setAsRef(Measurement m, MTempRef ref)
	{
		if(!m.getMeasurement().mdim.equals(ref.getDim()))
		{
			//TODO Exception Setting
			throw CommonExcLog.logError(
					new IllegalArgumentException("Cannot set Measurement: " + m 
							+ " to MTemp Reference: " + ref + "For they have other dimension"));
		}
		
		m.set(getInvStdVal(m.getMeasurement(), m.getUnit()));
	}
	
	protected static double getStdVal(MInfo mi, String unit)
	{
		//For Angle
		if(mi.mdim.equals(angle))
		{
			if(ratemode)
			{
				return mi.toStandard(1.0, unit);
			}
			else
			{
				return mi.fromStandard(mi.toStandard(1.0, unit), anglemode);
			}
		}
		
		InterMDimension idim = mi.mdim;
		
		double siv = mi.toStandard(1.0, unit);
		
		for(int i = 0; i < basestds.size(); i++)
		{
			if(idim.list.get(i) > 0)
			{
				for(int j = 0; j < idim.list.get(i); j++)
					siv *= invstd.get(i);
			}
		}
		
		return siv;
	}
	
	public static double getInvStdVal(MInfo mi, String unit)
	{
		//For Angle
		if(mi.mdim.equals(angle))
		{
			if(ratemode)
			{
				return mi.fromStandard(1.0, unit);
			}
			else
			{
				return mi.toStandard(mi.fromStandard(1.0, unit), anglemode);
			}
		}
		
		InterMDimension idim = mi.mdim;
		
		double siv = mi.fromStandard(1.0, unit);
				
		for(int i = 0; i < basestds.size(); i++)
		{
			if(idim.list.get(i) > 0)
			{
				for(int j = 0; j < idim.list.get(i); j++)
					siv *= stdval.get(i);
			}
		}
				
		return siv;		
	}
	
	public static MTempRef temporize(IValRef<Measurement> ref)
	{
		if(ref instanceof MTempRef)
			return (MTempRef) ref;
		
		MTempRef tmp = MeasurementSet.provideMTemp();
		tmp.set(ref.getVal());
		return tmp;
	}
}

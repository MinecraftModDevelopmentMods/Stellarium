package sciapi.api.unit;

import sciapi.api.temporaries.Temporal;
import sciapi.api.unit.UnitDictionary.MInfo;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.absalg.IVectorSpace;
import sciapi.api.value.absalg.VectorSpace;
import sciapi.api.value.numerics.IReal;

public class MeasurementSet extends VectorSpace<Measurement, IReal> implements
		IVectorSpace<Measurement, IReal> {

	protected MInfo minfo;
	
	protected Measurement zero;
	
	public MeasurementSet(MInfo mi, IField pset) {
		super(pset);
		
		minfo = mi;
		
		add = new IGroupOperator<Measurement>() {

			@Temporal
			@Override
			public IValRef<Measurement> calc(IValRef<Measurement> par1,
					IValRef<Measurement> par2) {
				MTempRef p = UnitCalc.temporize(par1);
				MTempRef ret = UnitCalc.temporize(par2);
				
				ret.setDVal(p.getDVal() + ret.getDVal());
				
				p.onUsed();
				
				return ret;
			}

			@Override
			public IValRef<Measurement> identity() {
				if(zero == null)
				{
					zero = getNew();
					zero.set(0.0);
				}
				
				return zero;
			}

			@Temporal
			@Override
			public IValRef<Measurement> inverse(IValRef<Measurement> par) {
				MTempRef ret = UnitCalc.temporize(par);
				
				ret.setDVal(-ret.getDVal());
				
				return ret;
			}
			
		};
		
		sub = new IBiOperator<Measurement, Measurement, Measurement>() {

			@Temporal
			@Override
			public IValRef<Measurement> calc(IValRef<Measurement> par1,
					IValRef<Measurement> par2) {
				MTempRef p = UnitCalc.temporize(par1);
				MTempRef ret = UnitCalc.temporize(par2);
				
				ret.setDVal(p.getDVal() - ret.getDVal());
				
				p.onUsed();
				
				return ret;
			}
			
		};
		
		mult = new IBiOperator<Measurement, IReal, Measurement>() {

			@Temporal
			@Override
			public IValRef<Measurement> calc(IValRef<IReal> par1,
					IValRef<Measurement> par2) {
				MTempRef ret = UnitCalc.temporize(par2);
				
				ret.setDVal(par1.getVal().asDouble() * ret.getDVal());
				
				par1.onUsed();
				
				return ret;
			}
			
		};
		
		div = new IBiOperator<Measurement, IReal, Measurement>() {

			@Temporal
			@Override
			public IValRef<Measurement> calc(IValRef<IReal> par1,
					IValRef<Measurement> par2) {
				MTempRef ret = UnitCalc.temporize(par2);
				
				ret.setDVal(ret.getDVal() / par1.getVal().asDouble());
				
				par1.onUsed();
				
				return ret;
			}
			
		};		
	}

	@Override
	public Measurement getNew() {
		return UnitDictionary.instance().getNew(minfo);
	}
	
	public static MTempRef provideMTemp()
	{
		return UnitDictionary.instance().tprov.getTemp();
	}

}

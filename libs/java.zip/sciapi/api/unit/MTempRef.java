package sciapi.api.unit;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.temporaries.Temporal;
import sciapi.api.unit.UnitDictionary.InterMDimension;
import sciapi.api.unit.UnitDictionary.MInfo;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;

/**Temporal Reference for Measurement*/
@Temporal
public class MTempRef implements IValRef<Measurement> {

	private double val;
	private InterMDimension dim;
	
	@Override
	public void onUsed() {
		UnitDictionary.instance().tprov.release(this);
	}

	@Deprecated
	@Override
	public Measurement getVal() {
		return null;
	}

	@Override
	public IValSet<Measurement> getParentSet() {
		
		MInfo mi = UnitDictionary.instance().unitdimmap.get(dim);
		
		if(mi != null)
		{
			return mi.parset;
		}
		else
		{
			throw CommonExcLog.logError(
					new IllegalArgumentException("This Reference have Invalid Unit! Cannot get the parent set!"));
		}
	}
	
	public InterMDimension getDim()
	{
		return this.dim;
	}
	
	public double getDVal()
	{
		return this.val;
	}
	
	public void setDVal(double v)
	{
		this.val = v;
	}
	
	public void setDim(InterMDimension mdim)
	{
		this.dim = mdim;
	}

	@Override
	public Measurement set(IValRef<Measurement> val) {
		if(val instanceof MTempRef)
		{
			this.dim = ((MTempRef)val).dim;
			this.val = ((MTempRef)val).val;
		}
		else
		{
			this.dim = val.getVal().getMeasurement().mdim;
			this.val = UnitCalc.getStdVal(val.getVal());
		}
		
		val.onUsed();
		
		return val.getVal();
	}

}

package sciapi.api.unit;

public class MDimension {
	public String[] basename;
	
	/**
	 * Form Dimension By Base Names.
	 * */
	public MDimension(String... pbasename){
		basename = pbasename;
	}
}

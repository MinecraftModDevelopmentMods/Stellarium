package sciapi.api.registry;

import java.util.ArrayList;
import java.util.List;

import sciapi.api.pinterface.*;
import sciapi.api.pinterface.def.LogManager;
import sciapi.api.pinterface.def.SciLogFilter;

public class PInterface {
		
	public static LogManager logger = new LogManager();
	
	public static SciLogFilter scifilter = new SciLogFilter();
	
	public static ILogger getLogger()
	{
		return logger;
	}
	
	public static void registerLogger(String id, ILogger l)
	{
		logger.addLogger(id, l);
	}

	public static void addFilter(String id, ILogFilter f)
	{
		logger.addFilter(id, f);
	}
	
	public static void removeFilter(String id, ILogFilter f)
	{
		logger.removeFilter(id, f);
	}
}

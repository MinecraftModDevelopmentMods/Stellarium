/**
 * 
 */
/**
 * 
 * Registrations for the Scientific API.
 * 
 * @author Astros
 *
 */
package sciapi.api.registry;
package sciapi.api.value;

public abstract class GroupOperator<V extends IValue> extends BiOperator<V, V, V> implements
		IGroupOperator<V> {

	@Override
	public IValRef<V> inverse(IValRef<V> par) {
		par.onUsed();
		return null;
	}

}

package sciapi.api.value;

import sciapi.api.temporaries.Temporal;

public interface IUnaryOperator <R extends IValue, S extends IValue> {
	
	/**Calculates the result by this operator*/
	@Temporal
	public IValRef<R> calc(IValRef<S> par1);

}

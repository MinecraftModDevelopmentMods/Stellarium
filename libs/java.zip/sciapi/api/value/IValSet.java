package sciapi.api.value;

import sciapi.api.abstraction.util.IProviderBase;
import sciapi.api.temporaries.Temporal;

public interface IValSet <V extends IValue> extends IProviderBase<V> {

	/**Gives new instance from this value set*/
	public V getNew();
	
	/**Gives single-use temporal instance from this value set*/
	@Temporal
	public STempRef<V> getSTemp();
	
	/**Release single-use temporal instance from this value set*/
	public void releaseTemp(STempRef<V> tmp);
	
}

package sciapi.api.value;

public class UnaryOperator<R extends IValue, S extends IValue> implements IUnaryOperator<R, S> {

	@Override
	public IValRef<R> calc(IValRef<S> par1) {
		par1.onUsed();
		
		return null;
	}

}

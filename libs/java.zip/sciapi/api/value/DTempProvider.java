package sciapi.api.value;

import sciapi.api.abstraction.util.IProviderBase;
import sciapi.api.temporaries.TempUtil;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.numerics.DDouble;

public class DTempProvider<V extends IValue> implements IProviderBase<DTempRef<V>>{

	private TempUtil<DTempRef<V>> temprov;
	private IValSet<V> pset;
	
	public DTempProvider(IValSet<V> par)
	{
		temprov = new TempUtil<DTempRef<V>>(this);
		pset = par;
	}
	
	@Temporal
	@Override
	public DTempRef<V> getNew() {
		V val = pset.getNew();
		DTempRef<V> tmp = new DTempRef<V>();
		tmp.setVal(val);
		return tmp;
	}
	
	@Temporal
	public DTempRef<V> getTemp() {
		DTempRef<V> tmp = temprov.getTemp();
		return tmp;
	}
	
	public void release(DTempRef<V> tmp) {
		temprov.release(tmp);
	}

}

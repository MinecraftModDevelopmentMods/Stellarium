package sciapi.api.value;

public interface IValue <V extends IValue> extends IValRef<V> {

	/**Gives the parent set of this value.*/
	public IValSet<V> getParentSet();

}

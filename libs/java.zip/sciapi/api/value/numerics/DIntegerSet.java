package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IComparator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;

public class DIntegerSet extends ScalarSet<DInteger> {

	public static DIntegerSet ins = new DIntegerSet();
	
	public DInteger zero, one;
	
	public DIntegerSet()
	{
		super();
		
		zero = new DInteger(0);
		one = new DInteger(1);
		
		add = new IGroupOperator<DInteger>() {
			
			@Temporal
			@Override
			public IValRef<DInteger> calc(IValRef<DInteger> par1, IValRef<DInteger> par2) {
				STempRef<DInteger> temp = getSTemp();
				temp.getVal().set(par1.getVal().value + par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DInteger> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DInteger> inverse(IValRef<DInteger> par) {
				STempRef<DInteger> temp = getSTemp();
				temp.getVal().set(-par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IGroupOperator<DInteger>() {
			
			@Temporal
			@Override
			public IValRef<DInteger> calc(IValRef<DInteger> par1, IValRef<DInteger> par2) {
				STempRef<DInteger> temp = getSTemp();
				temp.getVal().set(par1.getVal().value * par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DInteger> identity() {
				return one;
			}

			@Deprecated
			@Override
			public IValRef<DInteger> inverse(IValRef<DInteger> par) {
				return null;
			}
			
		};
		
		sub = new IBiOperator<DInteger, DInteger, DInteger>() {

			@Temporal
			@Override
			public IValRef<DInteger> calc(IValRef<DInteger> par1, IValRef<DInteger> par2) {
				STempRef<DInteger> temp = getSTemp();
				temp.getVal().set(par1.getVal().value - par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DInteger, DInteger, DInteger>() {

			@Temporal
			@Override
			public IValRef<DInteger> calc(IValRef<DInteger> par1, IValRef<DInteger> par2) {
				STempRef<DInteger> temp = getSTemp();
				temp.getVal().set(par1.getVal().value / par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		comp = new IComparator<DInteger>() {

			@Override
			public int compare(IValRef<DInteger> par1, IValRef<DInteger> par2) {	
				if(par1.getVal().value > par2.getVal().value)
					return 1;
				if(par1.getVal().value == par2.getVal().value)
					return 0;
				return -1;
			}
			
		};
	}
	
	@Override
	public DInteger getNew() {
		return new DInteger();
	}

}

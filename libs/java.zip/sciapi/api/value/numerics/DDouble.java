package sciapi.api.value.numerics;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;

public class DDouble implements IReal<DDouble> {

	private DDoubleSet par;
	protected double value = 0.0;
	
	public DDouble() { par = DDoubleSet.ins; }
	public DDouble(double d) { par = DDoubleSet.ins; value = d; }
	public DDouble(DDoubleSet p) { par = p; }
	public DDouble(DDoubleSet p, double d) { par = p; value = d; }

	@Override
	public IValSet<DDouble> getParentSet() {
		return par;
	}

	@Override
	public DDouble set(IValRef val) {
		value = ((IReal)val.getVal()).asDouble();
		val.onUsed();
		
		return this;
	}

	@Override
	public void onUsed() {
		//Do nothing when used.
	}

	@Override
	public DDouble getVal() {
		return this;
	}

	@Override
	public void set(double val) {
		value = val;
	}

	@Override
	public void set(float val) {
		value = val;
	}

	@Override
	public double asDouble() {
		return value;
	}

	@Override
	public float asFloat() {
		return (float) value;
	}

	@Override
	public String toString()
	{
		return "DDouble:" + value;
	}
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof IReal)
		{
			return this.value == ((IReal)o).asDouble();
		}
		
		return false;
	}

}

package sciapi.api.value.numerics;

import sciapi.api.value.IComparator;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.Field;

public abstract class ScalarSet<V extends IValue> extends Field<V> implements IScalarSet<V> {

	IComparator<V> comp;
	
	@Override
	public IComparator<V> comp() {
		return comp;
	}

}

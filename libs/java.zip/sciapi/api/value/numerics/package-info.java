/**
 * 
 */
/**
 * 
 * Contains Real & Integer values to manage the numerics.
 * 
 * @author Astros
 *
 */
package sciapi.api.value.numerics;

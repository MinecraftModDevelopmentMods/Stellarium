package sciapi.api.value.numerics;

import sciapi.api.value.IValue;

public interface IInteger<V extends IInteger> extends IValue<V> {
	/**Sets this value with integer*/
	public void set(int val);
	
	/**Sets this value with long*/
	public void set(long val);
	
	/**Sets this value with short*/
	public void set(short val);

	/**Sets this value with byte*/
	public void set(byte val);
	
	
	/**Gets this value as integer*/
	public int asInt();

	/**Gets this value as long*/
	public long asLong();
	
	/**Gets this value as short*/
	public short asShort();
	
	/**Gets this value as byte*/
	public byte asByte();
}

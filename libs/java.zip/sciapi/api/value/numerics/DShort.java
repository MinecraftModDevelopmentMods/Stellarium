package sciapi.api.value.numerics;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;

public class DShort implements IInteger<DShort> {

	private DShortSet par;
	protected short value = 0;
	
	public DShort() { par = DShortSet.ins; }
	public DShort(short d) { par = DShortSet.ins; value = d; }
	public DShort(DShortSet p) { par = p; }
	public DShort(DShortSet p, short d) { par = p; value = d; }

	@Override
	public IValSet<DShort> getParentSet() {
		return par;
	}

	@Override
	public DShort set(IValRef val) {
		value = ((IInteger)val.getVal()).asShort();
		val.onUsed();
		
		return this;
	}

	@Override
	public void onUsed() {
		//Do nothing when used.
	}

	@Override
	public DShort getVal() {
		return this;
	}
	
	@Override
	public void set(int val) {
		value = (short) val;
	}
	
	@Override
	public void set(long val) {
		value = (short) val;
	}
	
	@Override
	public void set(short val) {
		value = val;
	}
	
	@Override
	public void set(byte val) {
		value = val;
	}
	
	@Override
	public int asInt() {
		return value;
	}
	
	@Override
	public long asLong() {
		return value;
	}
	
	@Override
	public short asShort() {
		return value;
	}
	
	@Override
	public byte asByte() {
		return (byte) value;
	}

	
	@Override
	public String toString()
	{
		return "DShort:" + value;
	}
	
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof IInteger)
		{
			return this.value == ((IInteger)o).asShort();
		}
		
		return false;
	}
}

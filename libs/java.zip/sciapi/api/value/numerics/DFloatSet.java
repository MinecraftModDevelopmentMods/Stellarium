package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IComparator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;

public class DFloatSet extends ScalarSet<DFloat> {

	public static DFloatSet ins = new DFloatSet();
		
	public DFloat zero, one;
	
	public DFloatSet()
	{
		super();
		
		zero = new DFloat(0.0f);
		one = new DFloat(1.0f);
		
		add = new IGroupOperator<DFloat>() {
			
			@Temporal
			@Override
			public IValRef<DFloat> calc(IValRef<DFloat> par1, IValRef<DFloat> par2) {
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(par1.getVal().value + par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DFloat> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DFloat> inverse(IValRef<DFloat> par) {
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(-par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IGroupOperator<DFloat>() {
			
			@Temporal
			@Override
			public IValRef<DFloat> calc(IValRef<DFloat> par1, IValRef<DFloat> par2) {
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(par1.getVal().value * par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DFloat> identity() {
				return one;
			}

			@Temporal
			@Override
			public IValRef<DFloat> inverse(IValRef<DFloat> par) {				
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(1 / par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<DFloat, DFloat, DFloat>() {

			@Temporal
			@Override
			public IValRef<DFloat> calc(IValRef<DFloat> par1, IValRef<DFloat> par2) {
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(par1.getVal().value - par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DFloat, DFloat, DFloat>() {

			@Temporal
			@Override
			public IValRef<DFloat> calc(IValRef<DFloat> par1, IValRef<DFloat> par2) {
				STempRef<DFloat> temp = getSTemp();
				temp.getVal().set(par1.getVal().value / par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		comp = new IComparator<DFloat>() {

			@Override
			public int compare(IValRef<DFloat> par1, IValRef<DFloat> par2) {
				if(par1.getVal().value > par2.getVal().value)
					return 1;
				if(par1.getVal().value == par2.getVal().value)
					return 0;
				return -1;
			}
			
		};
	}

	
	@Override
	public DFloat getNew() {
		return new DFloat();
	}

}

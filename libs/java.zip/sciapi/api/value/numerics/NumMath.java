package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.util.BOp;

/**Numerical Math for Real*/
public class NumMath {
	
	public static IUnaryOperator<IReal, IReal> floor = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.floor(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> ceil = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.ceil(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> sqrt = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.sqrt(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> sqr = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IScalarSet<IReal> scSet = (IScalarSet<IReal>) par1.getParentSet();
			
			IValRef<IReal> res = scSet.getSTemp();
			
			res.set(BOp.mult(par1, par1));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> exp = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.exp(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IBiOperator<IReal, IReal, IReal> pow = new IBiOperator<IReal, IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1, IValRef<IReal> par2) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.pow(par1.getVal().asDouble(), par2.getVal().asDouble()));
			
			par1.onUsed();
			par2.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> expm1 = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.expm1(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> log = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.log(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> log1p = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.log1p(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> log10 = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.log10(par1.getVal().asDouble()));
			
			par1.onUsed();

			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> cos = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.cos(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> sin = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.sin(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> tan = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.tan(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> toRad = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.toRadians(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> toDeg = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.toDegrees(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> acos = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.acos(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> asin = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.asin(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> atan = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.atan(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IBiOperator<IReal, IReal, IReal> atan2 = new IBiOperator<IReal, IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1, IValRef<IReal> par2) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.atan2(par1.getVal().asDouble(), par2.getVal().asDouble()));
			
			par1.onUsed();
			par2.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> sinh = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.sinh(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> cosh = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.cosh(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
	
	public static IUnaryOperator<IReal, IReal> tanh = new IUnaryOperator<IReal, IReal>() {

		@Temporal
		@Override
		public IValRef<IReal> calc(IValRef<IReal> par1) {
			IValRef<IReal> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(Math.tanh(par1.getVal().asDouble()));
			
			par1.onUsed();
			
			return res;
		}
		
	};
}

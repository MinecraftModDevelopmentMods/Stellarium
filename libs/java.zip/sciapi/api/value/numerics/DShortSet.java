package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IComparator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;

public class DShortSet extends ScalarSet<DShort> {

	public static DShortSet ins = new DShortSet();
		
	public DShort zero, one;
	
	public DShortSet()
	{
		super();
		
		zero = new DShort((short)0);
		one = new DShort((short)1);
		
		add = new IGroupOperator<DShort>() {
			
			@Temporal
			@Override
			public IValRef<DShort> calc(IValRef<DShort> par1, IValRef<DShort> par2) {
				STempRef<DShort> temp = getSTemp();
				temp.getVal().set(par1.getVal().value + par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DShort> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DShort> inverse(IValRef<DShort> par) {				
				STempRef<DShort> temp = getSTemp();
				temp.getVal().set(-par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IGroupOperator<DShort>() {
			
			@Temporal
			@Override
			public IValRef<DShort> calc(IValRef<DShort> par1, IValRef<DShort> par2) {
				STempRef<DShort> temp = getSTemp();
				temp.getVal().set(par1.getVal().value * par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DShort> identity() {
				return one;
			}

			@Deprecated
			@Override
			public IValRef<DShort> inverse(IValRef<DShort> par) {				
				return null;
			}
			
		};
		
		sub = new IBiOperator<DShort, DShort, DShort>() {

			@Temporal
			@Override
			public IValRef<DShort> calc(IValRef<DShort> par1, IValRef<DShort> par2) {
				STempRef<DShort> temp = getSTemp();
				temp.getVal().set(par1.getVal().value - par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DShort, DShort, DShort>() {

			@Temporal
			@Override
			public IValRef<DShort> calc(IValRef<DShort> par1, IValRef<DShort> par2) {
				STempRef<DShort> temp = getSTemp();
				temp.getVal().set(par1.getVal().value / par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		comp = new IComparator<DShort>() {
			@Override
			public int compare(IValRef<DShort> par1, IValRef<DShort> par2) {
				if(par1.getVal().value > par2.getVal().value)
					return 1;
				if(par1.getVal().value == par2.getVal().value)
					return 0;
				return -1;
			}
			
		};
	}
	
	@Override
	public DShort getNew() {
		return new DShort();
	}

}

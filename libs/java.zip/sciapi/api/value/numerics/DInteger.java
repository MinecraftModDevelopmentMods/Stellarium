package sciapi.api.value.numerics;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;

public class DInteger implements IInteger<DInteger> {

	private DIntegerSet par;
	protected int value = 0;
	
	public DInteger() { par = DIntegerSet.ins; }
	public DInteger(int d) { par = DIntegerSet.ins; value = d; }
	public DInteger(DIntegerSet p) { par = p; }
	public DInteger(DIntegerSet p, int d) { par = p; value = d; }

	@Override
	public IValSet<DInteger> getParentSet() {
		return par;
	}

	@Override
	public DInteger set(IValRef val) {
		value = ((IInteger)val.getVal()).asInt();
		val.onUsed();
		
		return this;
	}

	@Override
	public void onUsed() {
		//Do nothing when used.
	}

	@Override
	public DInteger getVal() {
		return this;
	}
	
	@Override
	public void set(int val) {
		value = val;
	}
	
	@Override
	public void set(long val) {
		value = (int) val;
	}
	
	@Override
	public void set(short val) {
		value = val;
	}
	
	@Override
	public void set(byte val) {
		value = val;
	}
	
	@Override
	public int asInt() {
		return value;
	}
	
	@Override
	public long asLong() {
		return value;
	}
	
	@Override
	public short asShort() {
		return (short) value;
	}
	
	@Override
	public byte asByte() {
		return (byte) value;
	}

	
	@Override
	public String toString()
	{
		return "DInteger:" + value;
	}
	
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof IInteger)
		{
			return this.value == ((IInteger)o).asInt();
		}
		
		return false;
	}
}

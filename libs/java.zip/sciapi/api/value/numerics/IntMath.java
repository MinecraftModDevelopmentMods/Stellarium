package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IValRef;

/**Math for Integers*/
public class IntMath {
	
	/**Modulus Operator*/
	public static IBiOperator<IInteger, IInteger, IInteger> mod = new IBiOperator<IInteger, IInteger, IInteger>() {

		@Temporal
		@Override
		public IValRef<IInteger> calc(IValRef<IInteger> par1, IValRef<IInteger> par2) {
			IValRef<IInteger> res = par1.getParentSet().getSTemp();
			
			res.getVal().set(par1.getVal().asInt() % par2.getVal().asInt());
			
			par1.onUsed();
			par2.onUsed();
			
			return res;
		}
		
	};
}

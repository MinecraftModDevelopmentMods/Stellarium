package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IComparator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;

public class DDoubleSet extends ScalarSet<DDouble> {

	public static DDoubleSet ins = new DDoubleSet();
	
	public DDouble zero, one;
	
	public DDoubleSet()
	{
		super();
		
		zero = new DDouble(0.0);
		one = new DDouble(1.0);
		
		add = new IGroupOperator<DDouble>() {
			
			@Temporal
			@Override
			public IValRef<DDouble> calc(IValRef<DDouble> par1, IValRef<DDouble> par2) {
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(par1.getVal().value + par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DDouble> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DDouble> inverse(IValRef<DDouble> par) {			
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(-par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IGroupOperator<DDouble>() {
			
			@Temporal
			@Override
			public IValRef<DDouble> calc(IValRef<DDouble> par1, IValRef<DDouble> par2) {
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(par1.getVal().value * par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				
				return temp;
			}

			@Override
			public IValRef<DDouble> identity() {
				return one;
			}

			@Temporal
			@Override
			public IValRef<DDouble> inverse(IValRef<DDouble> par) {
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(1 / par.getVal().value);
				
				par.onUsed();	
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<DDouble, DDouble, DDouble>() {

			@Temporal
			@Override
			public IValRef<DDouble> calc(IValRef<DDouble> par1, IValRef<DDouble> par2) {
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(par1.getVal().value - par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DDouble, DDouble, DDouble>() {

			@Temporal
			@Override
			public IValRef<DDouble> calc(IValRef<DDouble> par1, IValRef<DDouble> par2) {
				STempRef<DDouble> temp = getSTemp();
				temp.getVal().set(par1.getVal().value / par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		comp = new IComparator<DDouble>() {

			@Override
			public int compare(IValRef<DDouble> par1, IValRef<DDouble> par2) {
				if(par1.getVal().value > par2.getVal().value)
					return 1;
				if(par1.getVal().value == par2.getVal().value)
					return 0;
				return -1;
			}
			
		};
	}
	
	@Override
	public DDouble getNew() {
		return new DDouble();
	}
}

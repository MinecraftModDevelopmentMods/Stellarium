package sciapi.api.value.numerics;

import sciapi.api.value.IValue;

public interface IReal<V extends IReal> extends IValue<V> {
	/**Sets this value with double*/
	public void set(double val);
	
	/**Sets this value with float*/
	public void set(float val);

	/**Gets this value as double*/
	public double asDouble();

	/**Gets this value as float*/
	public float asFloat();

}

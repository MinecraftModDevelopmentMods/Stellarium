package sciapi.api.value.numerics;

import sciapi.api.value.IValue;
import sciapi.api.value.absalg.ICompSet;
import sciapi.api.value.absalg.IField;

/**Set for Scalar value. It is simply Field & Comparable Set*/
public interface IScalarSet<V extends IValue> extends IField<V>, ICompSet<V> {

}

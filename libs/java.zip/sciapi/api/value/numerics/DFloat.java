package sciapi.api.value.numerics;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;

public class DFloat implements IReal<DFloat> {

	private DFloatSet par;
	protected float value = 0.0f;
	
	public DFloat() { par = DFloatSet.ins; }
	public DFloat(float d) { par = DFloatSet.ins; value = d; }
	public DFloat(DFloatSet p) { par = p; }
	public DFloat(DFloatSet p, float d) { par = p; value = d; }

	@Override
	public IValSet<DFloat> getParentSet() {
		return par;
	}

	@Override
	public DFloat set(IValRef val) {
		value = ((IReal)val.getVal()).asFloat();
		val.onUsed();
		
		return this;
	}

	@Override
	public void onUsed() {
		//Do nothing when used.
	}

	@Override
	public DFloat getVal() {
		return this;
	}

	@Override
	public void set(double val) {
		value = (float) val;
	}

	@Override
	public void set(float val) {
		value = val;
	}

	@Override
	public double asDouble() {
		return value;
	}

	@Override
	public float asFloat() {
		return value;
	}

	
	@Override
	public String toString()
	{
		return "DFloat:" + value;
	}
	
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof IReal)
		{
			return this.value == ((IReal)o).asFloat();
		}
		
		return false;
	}
}

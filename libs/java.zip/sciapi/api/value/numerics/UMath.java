package sciapi.api.value.numerics;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;
import sciapi.api.value.util.BOp;
import sciapi.api.value.util.Cons;

/**Universal Math (for Scalars)*/
public class UMath {
	
	public static IBiOperator<IValue, IValue, IValue> max = new IBiOperator<IValue, IValue, IValue>() {

		@Override
		public IValRef calc(IValRef par1, IValRef par2) {
			
			if(BOp.comp(par1, par2) >= 0)
			{
				par2.onUsed();
				return par1;
			}
			else
			{
				par1.onUsed();
				return par2;
			}
		}
		
	};
	
	public static IBiOperator<IValue, IValue, IValue> min = new IBiOperator<IValue, IValue, IValue>() {

		@Override
		public IValRef calc(IValRef par1, IValRef par2) {
			
			if(BOp.comp(par1, par2) >= 0)
			{
				par1.onUsed();
				return par2;
			}
			else
			{
				par2.onUsed();
				return par1;
			}
		}
		
	};
	
	public static IUnaryOperator<IValue, IValue> abs = new IUnaryOperator<IValue, IValue>() {

		@Override
		public IValRef calc(IValRef par1) {
			
			if(BOp.comp(par1, Cons.zero(par1)) >= 0)
			{
				return par1;
			}
			else
			{
				return BOp.minus(par1);
			}
		}
		
	};
}

package sciapi.api.value.numerics;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IComparator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;

public class DLongSet extends ScalarSet<DLong> {

	public static DLongSet ins = new DLongSet();
	
	public DLong zero, one;
	
	public DLongSet()
	{
		super();
		
		zero = new DLong(0);
		one = new DLong(1);
		
		add = new IGroupOperator<DLong>() {
			
			@Temporal
			@Override
			public IValRef<DLong> calc(IValRef<DLong> par1, IValRef<DLong> par2) {
				STempRef<DLong> temp = getSTemp();
				temp.getVal().set(par1.getVal().value + par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DLong> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DLong> inverse(IValRef<DLong> par) {
				STempRef<DLong> temp = getSTemp();
				temp.getVal().set(-par.getVal().value);
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IGroupOperator<DLong>() {
			
			@Temporal
			@Override
			public IValRef<DLong> calc(IValRef<DLong> par1, IValRef<DLong> par2) {
				STempRef<DLong> temp = getSTemp();
				temp.getVal().set(par1.getVal().value * par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DLong> identity() {
				return one;
			}

			@Deprecated
			@Override
			public IValRef<DLong> inverse(IValRef<DLong> par) {
				return null;
			}
			
		};
		
		sub = new IBiOperator<DLong, DLong, DLong>() {

			@Temporal
			@Override
			public IValRef<DLong> calc(IValRef<DLong> par1, IValRef<DLong> par2) {
				STempRef<DLong> temp = getSTemp();
				temp.getVal().set(par1.getVal().value - par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DLong, DLong, DLong>() {

			@Temporal
			@Override
			public IValRef<DLong> calc(IValRef<DLong> par1, IValRef<DLong> par2) {
				STempRef<DLong> temp = getSTemp();
				temp.getVal().set(par1.getVal().value / par2.getVal().value);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		comp = new IComparator<DLong>() {

			@Override
			public int compare(IValRef<DLong> par1, IValRef<DLong> par2) {
				if(par1.getVal().value > par2.getVal().value)
					return 1;
				if(par1.getVal().value == par2.getVal().value)
					return 0;
				return -1;
			}
			
		};
	}

	
	@Override
	public DLong getNew() {
		return new DLong();
	}

}

package sciapi.api.value.numerics;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;

public class DLong implements IInteger<DLong> {

	private DLongSet par;
	protected long value = 0;
	
	public DLong() { par = DLongSet.ins; }
	public DLong(int d) { par = DLongSet.ins; value = d; }
	public DLong(DLongSet p) { par = p; }
	public DLong(DLongSet p, int d) { par = p; value = d; }

	@Override
	public IValSet<DLong> getParentSet() {
		return par;
	}

	@Override
	public DLong set(IValRef val) {
		value = ((IInteger)val.getVal()).asLong();
		val.onUsed();
		
		return this;
	}

	@Override
	public void onUsed() {
		//Do nothing when used.
	}

	@Override
	public DLong getVal() {
		return this;
	}
	
	@Override
	public void set(int val) {
		value = val;
	}
	
	@Override
	public void set(long val) {
		value = val;
	}
	
	@Override
	public void set(short val) {
		value = val;
	}
	
	@Override
	public void set(byte val) {
		value = val;
	}
	
	@Override
	public int asInt() {
		return (int) value;
	}
	
	@Override
	public long asLong() {
		return value;
	}
	
	@Override
	public short asShort() {
		return (short) value;
	}
	
	@Override
	public byte asByte() {
		return (byte) value;
	}


	@Override
	public String toString()
	{
		return "DLong:" + value;
	}
	
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof IInteger)
		{
			return this.value == ((IInteger)o).asLong();
		}
		
		return false;
	}
}

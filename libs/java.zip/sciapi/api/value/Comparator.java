package sciapi.api.value;

public class Comparator<V extends IValue> implements IComparator<V> {

	@Override
	public int compare(IValRef<V> par1, IValRef<V> par2) {
		par1.onUsed();
		par2.onUsed();
		return 0;
	}

}

package sciapi.api.value;

public interface IComparator <V extends IValue> {

	/**
	 * Compares the two elements.
	 * @return 1 for par1 > par2, -1 for par1 < par2, 0 otherwise
	 * */
	public int compare(IValRef<V> par1, IValRef<V> par2);
	
}

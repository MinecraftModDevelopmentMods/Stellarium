package sciapi.api.value;

import sciapi.api.value.euclidian.EVector;

public abstract class ValSet<V extends IValue> implements IValSet<V> {

	public STempProvider<V> temp;
	
	public ValSet()
	{
		temp = new STempProvider<V>(this);
	}

	@Override
	public STempRef<V> getSTemp() {
		return temp.getTemp();
	}

	@Override
	public void releaseTemp(STempRef<V> tmp) {
		temp.release(tmp);
	}

}

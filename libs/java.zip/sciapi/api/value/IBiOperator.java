package sciapi.api.value;

import sciapi.api.temporaries.Temporal;

public interface IBiOperator <R extends IValue, S extends IValue, T extends IValue> {
	
	/**Calculates the result by this operator*/
	@Temporal
	public IValRef<R> calc(IValRef<S> par1, IValRef<T> par2);

}

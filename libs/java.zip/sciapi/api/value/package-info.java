/**
 * 
 */
/**
 * 
 * API for quantities, amounts, numbers, etc.
 * 
 * @author Astros
 *
 */
package sciapi.api.value;

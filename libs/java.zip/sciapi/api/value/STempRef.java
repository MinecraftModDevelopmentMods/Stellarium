package sciapi.api.value;

import java.util.Comparator;

import sciapi.api.temporaries.Temporal;

/**Single-Use Temporal Reference class. Automatically released on being used.*/
@Temporal
public class STempRef <V extends IValue> implements IValRef<V> {

	private V value;
	
	/**Setter only for Provider*/
	protected void setVal(V v)
	{
		value = v;
	}
	
	@Override
	public void onUsed() {
		getParentSet().releaseTemp(this);
	}

	@Override
	public V getVal() {
		return value;
	}

	@Override
	public IValSet<V> getParentSet() {
		return value.getParentSet();
	}

	@Override
	public V set(IValRef<V> val) {
		return (V) getVal().set(val);
	}

}

package sciapi.api.value;

public class BiOperator<R extends IValue, S extends IValue, T extends IValue>
 implements IBiOperator<R, S, T> {

	/*Default*/
	@Override
	public IValRef<R> calc(IValRef<S> par1, IValRef<T> par2) {
		par1.onUsed();
		par2.onUsed();
		return null;
	}

}

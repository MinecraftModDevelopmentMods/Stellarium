package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;
import sciapi.api.value.ValSet;

public abstract class AdditiveGroup<V extends IValue> extends ValSet<V> implements IAdditiveGroup<V> {

	protected IGroupOperator<V> add;
	protected IBiOperator<V, V, V> sub;

	@Override
	public IGroupOperator<V> opAdd() {
		return add;
	}

	@Override
	public IBiOperator<V, V, V> opSub() {
		return sub;
	}

}

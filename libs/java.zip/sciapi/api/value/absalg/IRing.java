package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;

public interface IRing <F extends IValue> extends IAdditiveGroup<F> {
		
	/**
	 * Gives Multiplication Operator
	 * 
	 * (Caution: Multiplication in Ring may not have any inverse element)
	 * */
	public IGroupOperator<F> opMult();

}

package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;

public interface IField <F extends IValue> extends IRing<F> {
	
	/**Gives Division Operator*/
	public IBiOperator<F,F,F> opDiv();

}

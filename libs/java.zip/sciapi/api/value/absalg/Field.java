package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IValue;

public abstract class Field<V extends IValue> extends Ring<V> implements IField<V> {

	protected IBiOperator<V, V, V> div;

	@Override
	public IBiOperator<V, V, V> opDiv() {
		return div;
	}

}

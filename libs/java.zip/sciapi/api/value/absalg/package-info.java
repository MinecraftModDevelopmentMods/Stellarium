/**
 * 
 */
/**
 * 
 * Contains Interfaces for Abstract Algebra.
 * (Also contains Comparable Set Interface)
 * 
 * @author Astros
 *
 */
package sciapi.api.value.absalg;

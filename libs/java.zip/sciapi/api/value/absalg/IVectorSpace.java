package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IValue;

public interface IVectorSpace<E extends IValue, C extends IValue> extends
		IAdditiveGroup<E> {
	
	/**Gets the scalar set for this vectorspace.*/
	public IField<C> getScalarSet();
	
	/**Gives Multiplication Operator*/
	public IBiOperator<E, C, E> opMult();
	
	/**Gives Division Operator*/
	public IBiOperator<E, C, E> opDiv();
}

package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IValue;

public abstract class VectorSpace<E extends IValue, C extends IValue>
 extends AdditiveGroup<E> implements IVectorSpace<E, C> {

	protected IField<C> scSet;
	
	protected IBiOperator<E, C, E> mult;
	protected IBiOperator<E, C, E> div;

	public VectorSpace(IField<C> pset)
	{
		super();
		scSet = pset;
	}
	
	@Override
	public IField<C> getScalarSet() {
		return scSet;
	}

	@Override
	public IBiOperator<E, C, E> opMult() {
		return mult;
	}

	@Override
	public IBiOperator<E, C, E> opDiv() {
		return div;
	}

}

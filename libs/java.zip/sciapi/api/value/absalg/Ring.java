package sciapi.api.value.absalg;

import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValue;

public abstract class Ring<V extends IValue> extends AdditiveGroup<V> implements
		IRing<V> {
	
	protected IGroupOperator<V> mult;

	@Override
	public IGroupOperator<V> opMult() {
		return mult;
	}

}

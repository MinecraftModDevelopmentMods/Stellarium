package sciapi.api.value.absalg;

import sciapi.api.value.IComparator;
import sciapi.api.value.IValue;

/**
 * Comparable Set. Any element in this set is comparable.
 * */
public interface ICompSet<V extends IValue> {
	
	/** Gives Comparator for this set*/
	public IComparator<V> comp();
	
}

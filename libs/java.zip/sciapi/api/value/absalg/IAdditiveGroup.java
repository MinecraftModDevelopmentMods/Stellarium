package sciapi.api.value.absalg;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IValSet;
import sciapi.api.value.IValue;

public interface IAdditiveGroup <F extends IValue> extends IValSet<F> {
	
	/**Gives Addition Operator*/
	public IGroupOperator<F> opAdd();
	
	/**Gives Subtraction Operator*/
	public IBiOperator<F,F,F> opSub();

}

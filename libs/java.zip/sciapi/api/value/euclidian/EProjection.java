package sciapi.api.value.euclidian;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.ITransformMatrixSet;

/**
 * Projection to another dimension.
 * */
public class EProjection implements ITransformation {

	IEVector coords[];
	IMatrix projmat;
	ITransformMatrixSet projset;
	
	public EProjection(IEVector... pcoords)
	{
		if(pcoords == null || pcoords.length < 1)
			throw CommonExcLog.logError(new IllegalArgumentException("The Parameter does not contain any Coordinates!"));
		
		coords = pcoords;
		
		IEVecSet set = (IEVecSet) coords[0].getParentSet();
		projset = set.getTransformMatrixSet(pcoords.length);
		projmat = (IMatrix) projset.getNew();
		
		for(int i = 0; i < projmat.getRowNum(); i++)
			for(int j = 0; j < projmat.getColumnNum(); j++)
				projmat.getElement(i, j).set(coords[i].getCoord(j));
	}
	
	public EProjection(IEVecSet set, IMatrix pprojmat)
	{
		if(set.getDimension() != pprojmat.getColumnNum())
			throw CommonExcLog.logError(new IllegalArgumentException("The Parameter vector set has wrong dimension; It has to be "
					+ pprojmat.getColumnNum() + ", but It has" + set.getDimension()));
		
		projmat = pprojmat;
		projset = (ITransformMatrixSet) pprojmat.getParentSet();
		coords = new IEVector[pprojmat.getRowNum()];
		
		for(int i = 0; i < pprojmat.getRowNum(); i++)
		{
			coords[i] = (IEVector) set.getNew();
			
			for(int j = 0; j < pprojmat.getColumnNum(); j++)
				coords[i].getCoord(j).set(pprojmat.getElement(i, j));
		}
	}
	
	/**Gets ith Coordinate (Direction) Vector*/
	public IEVector getCoord(int i)
	{
		return coords[i];
	}
	
	@Override
	public <V extends IEVector> IValRef<V> transform(IValRef<V> v) {
		return projset.getTransformed(projmat, v);
	}

	@Override
	public IValRef<IMatrix> getTransformationMatrix() {
		return projmat;
	}

}

package sciapi.api.value.euclidian;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.numerics.DInteger;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.IReal;


/**
 * Euclidian Vector for IInteger.
 * 
 * this class is Default Euclidian Vector.
 * */
public class EVecInt implements IEVector<EVecInt, IInteger> {	
	
	private EVecIntSet par;
	private IInteger value[];
	
	/**
	 * Creates a Vector as Zero Vector.
	 * */
	public EVecInt(EVecIntSet ppar){
		value = new DInteger[ppar.getDimension()];
		for(int i = 0; i < ppar.getDimension(); i++)
			value[i] = new DInteger();
		
		par = ppar;
	}
	
	/**
	 * Creates a Vector as Zero Vector from the default set.
	 * */
	public EVecInt(int dim){
		this(EVecIntSet.ins(dim));
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVecInt(EVecIntSet ppar, IInteger... coords){
		value = coords;
		par = ppar;
	}
	
	/**
	 * Creates a Vector via Coordinates from the default set.
	 * */
	public EVecInt(IInteger... coords){
		this(EVecIntSet.ins(coords.length), coords);
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVecInt(EVecIntSet ppar, int... coords){
		value = new DInteger[coords.length];
		
		for(int i = 0; i < coords.length; i++)
			value[i] = new DInteger(coords[i]);
		
		par = ppar;
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVecInt(int... coords){
		this(EVecIntSet.ins(coords.length));
		value = new DInteger[coords.length];
		
		for(int i = 0; i < coords.length; i++)
			value[i] = new DInteger(coords[i]);
	}

	
	public void set(int... coords){
		for(int i = 0; i < coords.length; i++)
			value[i].set(coords[i]);
	}
	
	
	@Override
	public boolean isZero() {
		for(IInteger val : value)
			if(val.asInt() != 0)
				return false;
		return true;
	}
	
	@Override
	public IValSet<EVecInt> getParentSet() {
		return par;
	}

	@Override
	public void onUsed() {
		//Does nothing.
	}

	@Override
	public EVecInt getVal() {
		return this;
	}

	@Override
	public EVecInt set(IValRef<EVecInt> val) {
		if(this.getDimension() != val.getVal().getDimension())
			throw new VecDimensionException(this, val.getVal(), "set");
		
		for(int i = 0; i < value.length; i++)
		{
			value[i].set(val.getVal().value[i]);
		}
		
		val.onUsed();

		return this;
	}

	@Override
	public IInteger getCoord(int N) {
		return value[N];
	}

	@Override
	public int getDimension() {
		return value.length;
	}
	
	@Override
	public boolean equals(Object o){
		EVecInt v = (EVecInt) o;
		if(v.getDimension() != this.getDimension())
			return false;
		for(int i = 0; i < value.length; i++)
			if(!value[i].equals(v.value[i]))
				return false;
		
		return true;
	}
	
	
	@Override
	public String toString()
	{
		String p = "EVecInt(";
		for(IInteger ite  : value)
		{
			p += ite.asInt();
			p += ",";
		}
		return p + ")";
	}

}

package sciapi.api.value.euclidian;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.numerics.DDouble;
import sciapi.api.value.numerics.DFloat;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.IReal;


/**
 * Euclidian Vector for IReal.
 * 
 * this class is Default Euclidian Vector.
 * */
public class EVector implements IEVector<EVector, IReal> {	
	
	private EVectorSet par;
	private IReal value[];
	
	/**
	 * Creates a Vector as Zero Vector.
	 * */
	public EVector(EVectorSet ppar){
		value = new DDouble[ppar.getDimension()];
		for(int i = 0; i < ppar.getDimension(); i++)
			value[i] = new DDouble();
		
		par = ppar;
	}
	
	/**
	 * Creates a Vector as Zero Vector from the default set.
	 * */
	public EVector(int dim){
		this(EVectorSet.ins(dim));
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVector(EVectorSet ppar, IReal... coords){
		value = coords;
		par = ppar;
	}
	
	/**
	 * Creates a Vector via Coordinates from the default set.
	 * */
	public EVector(IReal... coords){
		this(EVectorSet.ins(coords.length), coords);
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVector(EVectorSet ppar, double... coords){
		value = new DDouble[coords.length];
		
		for(int i = 0; i < coords.length; i++)
			value[i] = new DDouble(coords[i]);
		
		par = ppar;
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVector(double... coords){
		this(EVectorSet.ins(coords.length));
		value = new DDouble[coords.length];
		
		for(int i = 0; i < coords.length; i++)
			value[i] = new DDouble(coords[i]);
	}
	
	/**
	 * Creates a Vector via Coordinates.
	 * */
	public EVector(float... coords){
		this(EVectorSet.ins(coords.length));
		value = new DFloat[coords.length];
		
		for(int i = 0; i < coords.length; i++)
			value[i] = new DFloat(coords[i]);
	}

	
	public void set(double... coords){
		for(int i = 0; i < coords.length; i++)
			value[i].set(coords[i]);
	}
	
	
	@Override
	public boolean isZero() {
		for(IReal val : value)
			if(val.asDouble() != 0.0)
				return false;
		return true;
	}
	
	@Override
	public IValSet<EVector> getParentSet() {
		return par;
	}

	@Override
	public void onUsed() {
		//Does nothing.
	}

	@Override
	public EVector getVal() {
		return this;
	}

	@Override
	public EVector set(IValRef<EVector> val) {
		if(this.getDimension() != val.getVal().getDimension())
			throw new VecDimensionException(this, val.getVal(), "set");
		
		for(int i = 0; i < value.length; i++)
		{
			value[i].set(val.getVal().value[i]);
		}
		
		val.onUsed();
		
		return this;
	}

	@Override
	public IReal getCoord(int N) {
		return value[N];
	}

	@Override
	public int getDimension() {
		return value.length;
	}
	
	@Override
	public boolean equals(Object o){
		EVector v = (EVector) o;
		if(v.getDimension() != this.getDimension())
			return false;
		for(int i = 0; i < value.length; i++)
			if(!value[i].equals(v.value[i]))
				return false;
		
		return true;
	}
	
	@Override
	public String toString()
	{
		String p = "EVector(";
		for(IReal ite  : value)
		{
			p += ite.asDouble();
			p += ",";
		}
		return p + ")";
	}

}

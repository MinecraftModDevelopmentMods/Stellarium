package sciapi.api.value.euclidian;

import java.util.ArrayList;

import sciapi.api.posdiff.IAbsDiffSet;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.ITransformMatrixSet;
import sciapi.api.value.matrix.ZMatrix;
import sciapi.api.value.matrix.ZMatrixSet;
import sciapi.api.value.numerics.DIntegerSet;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.IScalarSet;
import sciapi.api.value.numerics.ScalarSet;

public class EVecIntSet extends AbsEVecSet<EVecInt, IInteger> implements IEVecSet<EVecInt, IInteger> {
		
	private static ArrayList<EVecIntSet> vecset = new ArrayList<EVecIntSet>(4);
	
	public static EVecIntSet ins(int N)
	{
		for(int i = vecset.size(); i < N; i++)
		{
			vecset.add(i, new EVecIntSet(DIntegerSet.ins, i+1));
		}
		
		return vecset.get(N-1);
	}
	
	public EVecInt zero;
	
	public EVecInt units[];
	
	public EVecIntSet(ScalarSet set, int pdim)
	{
		super(set, pdim);
		
		zero = new EVecInt(this);
		units = new EVecInt[pdim];
		
		for(int i = 0; i < pdim; i++)
		{
			units[i] = new EVecInt(this);
			units[i].getCoord(i).set(1);
		}
				
		add = new IGroupOperator<EVecInt>() {

			@Temporal
			@Override
			public IValRef<EVecInt> calc(IValRef<EVecInt> par1,
					IValRef<EVecInt> par2) {
				checkDimension(par1.getVal(), "add");
				checkDimension(par2.getVal(), "add");
				
				STempRef<EVecInt> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opAdd().calc(par1.getVal().getCoord(i),par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<EVecInt> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<EVecInt> inverse(IValRef<EVecInt> par) {
				checkDimension(par.getVal(), "addinv");

				STempRef<EVecInt> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opAdd().inverse(par.getVal().getCoord(i)));
				}
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<EVecInt, EVecInt, EVecInt>() {

			@Temporal
			@Override
			public IValRef<EVecInt> calc(IValRef<EVecInt> par1,
					IValRef<EVecInt> par2) {
				checkDimension(par1.getVal(), "sub");
				checkDimension(par2.getVal(), "sub");
				
				STempRef<EVecInt> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opSub().calc(par1.getVal().getCoord(i),par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IBiOperator<EVecInt, IInteger, EVecInt>() {

			@Temporal
			@Override
			public IValRef<EVecInt> calc(IValRef<IInteger> par1,
					IValRef<EVecInt> par2) {
				checkDimension(par2.getVal(), "mult");
				
				STempRef<EVecInt> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opMult().calc(par1, par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<EVecInt, IInteger, EVecInt>() {

			@Temporal
			@Override
			public IValRef<EVecInt> calc(IValRef<IInteger> par1,
					IValRef<EVecInt> par2) {
				checkDimension(par2.getVal(), "div");

				STempRef<EVecInt> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opDiv().calc(par2.getVal().getCoord(i), par1));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		dot = new IBiOperator<IInteger, EVecInt, EVecInt>() {

			@Temporal
			@Override
			public IValRef<IInteger> calc(IValRef<EVecInt> par1,
					IValRef<EVecInt> par2) {
				checkDimension(par1.getVal(), "dot");
				checkDimension(par2.getVal(), "dot");

				STempRef<IInteger> temp = getScalarSet().getSTemp();
				
				temp.set(getScalarSet().opAdd().identity());
				
				for(int i = 0; i < dim; i++)
				{
					temp.set(scSet.opAdd().calc(temp,
							scSet.opMult().calc(par1.getVal().getCoord(i), par2.getVal().getCoord(i))));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		size = new IUnaryOperator<IInteger, EVecInt>() {

			@Temporal
			@Override
			public IValRef<IInteger> calc(IValRef<EVecInt> par1) {
				return dot.calc(par1, par1);
			}
			
		};
	}
	

	@Override
	public EVecInt getNew() {
		return new EVecInt(this);
	}
	
	
	@Override
	public ITransformMatrixSet getTransformMatrixSet() {
		return ZMatrixSet.ins(dim, dim);
	}

	@Override
	public ITransformMatrixSet getTransformMatrixSet(int toDim) {
		return ZMatrixSet.ins(toDim, dim);
	}
	
	
	protected void checkDimension(EVecInt a, String procname){		
		if(a.getDimension() != dim)
			throw new VecDimensionException(a, dim, procname);
	}

}

package sciapi.api.value.euclidian;

import sciapi.api.basis.math.BMath;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.euclidian.*;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.MatrixSizeException;
import sciapi.api.value.util.BOp;
import sciapi.api.value.util.Cons;
import sciapi.api.value.util.MOp;
import sciapi.api.value.util.VOp;

/**
 * Reflection Transformation for Euclidian Vectors.
 * */
public class EReflect implements ITransformation {
	
	private IEVector refvec;
	
	/**
	 * @param pref the vector orthogonal to the reflection line(plane, space, and so on).
	 * @param isnorm a flag which indicates that the vector is normalized.
	 * */
	public EReflect(IEVector pref, boolean isnorm){
		if(isnorm)
		{
			refvec = pref;
		}
		else
		{
			refvec = (IEVector) pref.getParentSet().getNew();
			refvec.set(VOp.normalize(pref));
		}
	}
	
	@Temporal
	@Override
	public <V extends IEVector> IValRef<V> transform(IValRef<V> v) {
		IEVecSet set = (IEVecSet) v.getParentSet();
		IField sc = set.getScalarSet();
		
		STempRef<V> ret = set.getSTemp();
		
		IValRef tv = VOp.dot(v, refvec);
		
		ret.set(BOp.sub(v, VOp.mult(BOp.add(tv, tv), refvec)));
		
		v.onUsed();
		
		return ret;
	}

	@Temporal
	@Override
	public IValRef<IMatrix> getTransformationMatrix() {
		IEVecSet set = (IEVecSet) refvec.getParentSet();
		IField sc = set.getScalarSet();
		
		STempRef<IMatrix> ret = set.getTransformMatrixSet().getSTemp();
		IValue tv = sc.getNew();
		
		for(int i = 0; i < refvec.getDimension(); i++)
			for(int j = 0; j < refvec.getDimension(); j++)
			{
				tv.set(BOp.mult(refvec.getCoord(i), refvec.getCoord(j)));
				
				if(i == j)
					MOp.getElement(ret, i, j).set(BOp.sub(Cons.one(sc), BOp.add(tv, tv)));
				else MOp.getElement(ret, i, j).set(BOp.minus(BOp.add(tv, tv)));
			}
		
		return ret;
	}

}

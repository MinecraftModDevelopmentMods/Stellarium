package sciapi.api.value.euclidian;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.absalg.IField;

public class CrossUtil {
	
	/**
	 * get Cross Product of two vectors,
	 * as new instance.
	 * */
	@Temporal
	public static <V extends IEVector> IValRef<V> cross(IValRef<V> a, IValRef<V> b){
		DimensionCheck(a.getVal(), "Cross");
		DimensionCheck(b.getVal(), "Cross");
		
		IEVecSet set = (IEVecSet) a.getVal().getParentSet();
		IField sc = set.getScalarSet();
		
		IValRef<V> res = set.getSTemp();
		IValRef tmp;
		
		for(int i = 0; i < 3; i++){
			set.getCoord(res, i).set(
					sc.opMult().calc(set.getCoord(a, (i+1)%3), set.getCoord(b, (i+2)%3)));
			tmp = sc.opMult().calc(set.getCoord(a, (i+2)%3), set.getCoord(b, (i+1)%3));
			set.getCoord(res, i).set(
					sc.opSub().calc(set.getCoord(res, i), tmp));
		}
		
		a.onUsed();
		b.onUsed();
		
		return res;
	}
	
	private static void DimensionCheck(IEVector a, String proc){
		if(a.getDimension() != 3)
			throw new VecDimensionException(a, 3, proc);
	}
}

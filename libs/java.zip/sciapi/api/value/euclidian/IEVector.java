package sciapi.api.value.euclidian;

import sciapi.api.posdiff.*;
import sciapi.api.value.IValue;

/**
 * Euclidian Vector Interface.
 * */
public interface IEVector<V extends IEVector, S extends IValue> extends IAbsDifference<V> {
	
	/**
	 * get Nth Coordinate of this Vector.
	 * @param N from 0 to Dimension-1
	 * */
	public S getCoord(int N);
	
	
	/**
	 * get Dimension of this vector.
	 * */
	public int getDimension();
	
}

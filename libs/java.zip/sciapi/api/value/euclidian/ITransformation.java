package sciapi.api.value.euclidian;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.matrix.*;

public interface ITransformation {
	/**
	 * Gives the Transformed vector.
	 * */
	@Temporal
	public <V extends IEVector> IValRef<V> transform(IValRef<V> v);
	
	/**
	 * Gives Transformation Matrix for this Transformation.
	 * */
	@Temporal
	public IValRef<IMatrix> getTransformationMatrix();
}

package sciapi.api.value.euclidian;

import java.util.ArrayList;

import sciapi.api.posdiff.IAbsDiffSet;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.DTempProvider;
import sciapi.api.value.DTempRef;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempProvider;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.matrix.DMatrix;
import sciapi.api.value.matrix.DMatrixSet;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.ITransformMatrixSet;
import sciapi.api.value.numerics.DDouble;
import sciapi.api.value.numerics.DDoubleSet;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.numerics.IScalarSet;
import sciapi.api.value.numerics.ScalarSet;

public class EVectorSet extends AbsEVecSet<EVector, IReal> implements IEVecSet<EVector, IReal> {
		
	private static ArrayList<EVectorSet> vecset = new ArrayList<EVectorSet>(4);
	
	public static EVectorSet ins(int N)
	{
		for(int i = vecset.size(); i < N; i++)
		{
			vecset.add(i, new EVectorSet(DDoubleSet.ins, i+1));
		}
		
		return vecset.get(N-1);
	}
	
	public EVector zero;
	
	public EVector units[];
	
	public DTempProvider<IReal> prov;
	
	public EVectorSet(ScalarSet set, int pdim)
	{
		super(set, pdim);
		
		zero = new EVector(this);
		units = new EVector[pdim];
		
		prov = new DTempProvider<IReal>(set);
		
		for(int i = 0; i < pdim; i++)
		{
			units[i] = new EVector(this);
			units[i].getCoord(i).set(1.0);
		}
				
		add = new IGroupOperator<EVector>() {

			@Temporal
			@Override
			public IValRef<EVector> calc(IValRef<EVector> par1,
					IValRef<EVector> par2) {
				checkDimension(par1.getVal(), "add");
				checkDimension(par2.getVal(), "add");
				
				STempRef<EVector> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opAdd().calc(par1.getVal().getCoord(i),par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<EVector> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<EVector> inverse(IValRef<EVector> par) {
				checkDimension(par.getVal(), "addinv");

				STempRef<EVector> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opAdd().inverse(par.getVal().getCoord(i)));
				}
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<EVector, EVector, EVector>() {

			@Temporal
			@Override
			public IValRef<EVector> calc(IValRef<EVector> par1,
					IValRef<EVector> par2) {
				checkDimension(par1.getVal(), "sub");
				checkDimension(par2.getVal(), "sub");
				
				STempRef<EVector> temp = getSTemp();
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opSub().calc(par1.getVal().getCoord(i),par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IBiOperator<EVector, IReal, EVector>() {

			@Temporal
			@Override
			public IValRef<EVector> calc(IValRef<IReal> par1,
					IValRef<EVector> par2) {
				checkDimension(par2.getVal(), "mult");
				
				STempRef<EVector> temp = getSTemp();
				
				DTempRef<IReal> ref = prov.getTemp();
				ref.set(par1);
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opMult().calc(ref, par2.getVal().getCoord(i)));
				}
				
				prov.release(ref);
				
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<EVector, IReal, EVector>() {

			@Temporal
			@Override
			public IValRef<EVector> calc(IValRef<IReal> par1,
					IValRef<EVector> par2) {
				checkDimension(par2.getVal(), "div");
				
				STempRef<EVector> temp = getSTemp();
				
				DTempRef<IReal> ref = prov.getTemp();
				ref.set(par1);
				
				for(int i = 0; i < dim; i++)
				{
					temp.getVal().getCoord(i).set(
							scSet.opDiv().calc(par2.getVal().getCoord(i), ref));
				}
				
				prov.release(ref);
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		dot = new IBiOperator<IReal, EVector, EVector>() {

			@Temporal
			@Override
			public IValRef<IReal> calc(IValRef<EVector> par1,
					IValRef<EVector> par2) {
				checkDimension(par1.getVal(), "dot");
				checkDimension(par2.getVal(), "dot");
				
				IValRef<IReal> temp = getScalarSet().getSTemp();
				
				temp.set(getScalarSet().opAdd().identity());
				
				for(int i = 0; i < dim; i++)
				{
					temp = scSet.opAdd().calc(temp,
							scSet.opMult().calc(par1.getVal().getCoord(i), par2.getVal().getCoord(i)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		size = new IUnaryOperator<IReal, EVector>() {

			@Temporal
			@Override
			public IValRef<IReal> calc(IValRef<EVector> par1) {
				return dot.calc(par1, par1);
			}
			
		};
	}
	

	@Override
	public EVector getNew() {
		return new EVector(this);
	}
	

	@Override
	public ITransformMatrixSet getTransformMatrixSet() {
		return DMatrixSet.ins(dim, dim);
	}

	@Override
	public ITransformMatrixSet getTransformMatrixSet(int toDim) {
		return DMatrixSet.ins(toDim, dim);
	}
	
	
	protected void checkDimension(EVector a, String procname){
		if(a.getDimension() != dim)
			throw new VecDimensionException(a, dim, procname);
	}

}

package sciapi.api.value.euclidian;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.value.IValRef;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.ITransformMatrixSet;

public class ECoord extends EProjection {
	
	public ECoord(IEVector... pcoords)
	{
		super(pcoords);
		if(pcoords.length != pcoords[0].getDimension())
			throw CommonExcLog.logError(new IllegalArgumentException("The Number of the Coordinate Vectors is not same with the dimension!"));
	}
	
	public ECoord(IEVecSet set, IMatrix pprojmat)
	{
		super(set, pprojmat);
		if(pprojmat.getRowNum() != set.getDimension())
			throw CommonExcLog.logError(new IllegalArgumentException("The Projection Matrix is not square! "
					+ "It cannot be used as Coordinate-Conversion Matrix."));
	}
	
}

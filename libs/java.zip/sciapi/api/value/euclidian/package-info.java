/**
 * 
 */
/**
 * 
 * Euclidian Space API
 * (Commonly Used for Positions)
 * 
 * @author Astros
 *
 */
package sciapi.api.value.euclidian;

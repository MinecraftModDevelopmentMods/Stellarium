package sciapi.api.value.euclidian;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.MatrixSizeException;
import sciapi.api.value.util.BOp;
import sciapi.api.value.util.Cons;
import sciapi.api.value.util.MOp;
import sciapi.api.value.util.VOp;

/**
 * Scaling Transformation for Euclidian Vectors.
 * */
public class EScale implements ITransformation {
	
	public IEVector scale;
	
	public EScale (IEVector pscale){
		scale = pscale;
	}
	
	@Temporal
	@Override
	public <V extends IEVector> IValRef<V> transform(IValRef<V> v) {
		STempRef<V> ret = v.getParentSet().getSTemp();
		
		for(int i = 0; i < VOp.getDimension(v); i++)
			VOp.getCoord(ret, i).set(BOp.mult(VOp.getCoord(v, i), scale.getCoord(i)));
		
		v.onUsed();
		
		return null;
	}

	@Temporal
	@Override
	public IValRef<IMatrix> getTransformationMatrix() {
		IEVecSet set = (IEVecSet) scale.getParentSet();
		IField sc = set.getScalarSet();
		
		STempRef<IMatrix> ret = set.getTransformMatrixSet().getSTemp();
		
		for(int i = 0; i < scale.getDimension(); i++)
			for(int j = 0; j < scale.getDimension(); j++)
			{
				if(i != j)
					MOp.getElement(ret, i, j).set(Cons.zero(sc));
				else MOp.getElement(ret, i, j).set(scale.getCoord(i));
			}
		
		return ret;
	}

}

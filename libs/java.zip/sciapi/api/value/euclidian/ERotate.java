package sciapi.api.value.euclidian;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.numerics.NumMath;
import sciapi.api.value.util.BOp;
import sciapi.api.value.util.Cons;
import sciapi.api.value.util.MOp;
import sciapi.api.value.util.VOp;

/**
 * Rotation Transformation for Euclidian Vectors
 * */
public class ERotate implements ITransformation {

	//Vectors describing a plane
	protected IEVector a, b;
	
	protected IReal sin, m1cos;
	
	/**
	 * @param v1 a vector on the rotation plane
	 * @param v2 another vector on the plane, must not be same with first par
	 * @param isnorm a flag which indicates that the parameters are orthogonal and normalized.
	 * */
	public ERotate(IEVector v1, IEVector v2, boolean isprep){
		if(isprep)
		{
			a = v1;
			b = v2;
		}
		else
		{
			a = (IEVector) v1.getParentSet().getNew();
			b = (IEVector) v2.getParentSet().getNew();
			
			a.set(VOp.normalize(v1));
			b.set(VOp.normalize(BOp.sub(v2, VOp.mult(VOp.dot(a, v2), a))));
		}
		
		IField cs = ((IEVecSet)v1.getParentSet()).getScalarSet();
		
		sin = (IReal) cs.getNew();
		m1cos = (IReal) cs.getNew();
	}
	
	public void setAngle(double theta)
	{
		sin.set(Math.sin(theta));
		m1cos.set(1-Math.cos(theta));
	}
	
	public void setAngle(IReal theta)
	{
		sin.set(NumMath.sin.calc(theta));
		m1cos.set(BOp.sub(Cons.one(m1cos), NumMath.cos.calc(theta)));
	}
	
	@Override
	public <V extends IEVector> IValRef<V> transform(IValRef<V> v) {
		V vec = v.getParentSet().getNew();
		vec.set(v);
		
		return BOp.sub(vec, BOp.add(VOp.mult(VOp.dot(BOp.add(VOp.mult(m1cos, a), VOp.mult(sin, b)), vec), a),
				VOp.mult(VOp.dot(BOp.sub(VOp.mult(m1cos, b), VOp.mult(sin, a)), vec), b)));
	}

	@Override
	public IValRef<IMatrix> getTransformationMatrix() {
		IEVecSet set = (IEVecSet) a.getParentSet();
		IField sc = set.getScalarSet();
		
		STempRef<IMatrix> ret = set.getTransformMatrixSet().getSTemp();
		
		for(int i = 0; i < a.getDimension(); i++)
			for(int j = 0; j < a.getDimension(); j++)
			{
				if(i == j)
					MOp.getElement(ret, i, j).set(BOp.sub(Cons.one(sc),
							BOp.add(BOp.mult(BOp.add(BOp.mult(VOp.getCoord(a, i), VOp.getCoord(a, j)), BOp.mult(VOp.getCoord(b, i), VOp.getCoord(b, j))), m1cos),
									BOp.mult(BOp.sub(BOp.mult(VOp.getCoord(a, i), VOp.getCoord(b, j)), BOp.mult(VOp.getCoord(b, i), VOp.getCoord(a, j))), sin))));
				else MOp.getElement(ret, i, j).set(BOp.minus(
						BOp.add(BOp.mult(BOp.add(BOp.mult(VOp.getCoord(a, i), VOp.getCoord(a, j)), BOp.mult(VOp.getCoord(b, i), VOp.getCoord(b, j))), m1cos),
								BOp.mult(BOp.sub(BOp.mult(VOp.getCoord(a, i), VOp.getCoord(b, j)), BOp.mult(VOp.getCoord(b, i), VOp.getCoord(a, j))), sin))));
			}
		
		return ret;
	}

}

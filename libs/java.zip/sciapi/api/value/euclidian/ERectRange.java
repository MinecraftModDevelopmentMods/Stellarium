package sciapi.api.value.euclidian;

import sciapi.api.posdiff.*;
import sciapi.api.value.IValRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.numerics.IScalarSet;
import sciapi.api.value.util.BOp;
import sciapi.api.value.util.Cons;
import sciapi.api.value.util.VOp;

public class ERectRange<P extends IAbsPosition<P, EVector>> implements IAbsRange<ERectRange, P> {

	P p1, p2;
	
	public ERectRange(P point1, P point2){
		p1 = point1;
		p2 = point2;
	}

	@Override
	public boolean inRange(P pos) {
		IValRef<EVector> v1 = p1.getDifference(pos);
		IValRef<EVector> v2 = p2.getDifference(pos);
		
		IField sc = ((IEVecSet)v1.getParentSet()).getScalarSet();
		
		if(VOp.getDimension(v1) != VOp.getDimension(v2))
		{
			v1.onUsed();
			v2.onUsed();
			
			return false;
		}
		
		for(int i = 0; i < VOp.getDimension(v1); i++){
			if(!((BOp.isBigger(VOp.getCoord(v1, i), Cons.zero(sc))) ^ (BOp.isBigger(VOp.getCoord(v2, i), Cons.zero(sc))))){
				v1.onUsed();
				v2.onUsed();
				
				return false;
			}
		}
		
		v1.onUsed();
		v2.onUsed();
		
		return true;
	}

	@Override
	public boolean isOverlapped(ERectRange range) {
		IValRef<EVector> p1to1 = p1.getDifference((P) range.p1);
		IValRef<EVector> p2to1 = p2.getDifference((P) range.p1);
		IValRef<EVector> p1to2 = p1.getDifference((P) range.p2);
		IValRef<EVector> p2to2 = p2.getDifference((P) range.p2);
		
		IField sc = ((IEVecSet)p1to1.getParentSet()).getScalarSet();
		
		for(int i = 0; i < VOp.getDimension(p1to1); i++){
			if(!(BOp.isBigger(VOp.getCoord(p1to1, i), Cons.zero(sc))
					^ BOp.isBigger(VOp.getCoord(p2to1, i), Cons.zero(sc))
					^ BOp.isBigger(VOp.getCoord(p1to2, i), Cons.zero(sc))
					^ BOp.isBigger(VOp.getCoord(p2to2, i), Cons.zero(sc)))){
				
				p1to1.onUsed();
				p1to2.onUsed();
				p2to1.onUsed();
				p2to2.onUsed();
				
				return false;
			}
		}
		
		p1to1.onUsed();
		p1to2.onUsed();
		p2to1.onUsed();
		p2to2.onUsed();
		
		return true;
	}

	@Override
	public ERectRange getIntersect(ERectRange range) {
		if(!isOverlapped(range))
			return null;
		
		IValRef<EVector> p1to1 = p1.getDifference((P) range.p1);
		IValRef<EVector> p2to1 = p2.getDifference((P) range.p1);
		IValRef<EVector> p1to2 = p1.getDifference((P) range.p2);
		IValRef<EVector> p2to2 = p2.getDifference((P) range.p2);
		
		IValRef<EVector> v1 = p1to1.getParentSet().getNew(), v2 = p1to1.getParentSet().getNew();
		
		IField sc = ((IEVecSet)p1to1.getParentSet()).getScalarSet();
		
		for(int i = 0; i < VOp.getDimension(p1to1); i++){
			if(BOp.isBigger(VOp.getCoord(p1to1, i), Cons.zero(sc))
					^ BOp.isBigger(VOp.getCoord(p1to2, i), Cons.zero(sc))){
				VOp.getCoord(v1, i).set(Cons.zero(sc));
			}
			else VOp.getCoord(v1, i).set(BOp.sub(VOp.getCoord(p2to1, i), VOp.getCoord(p1to1, i)));
			
			if(BOp.isBigger(VOp.getCoord(p1to1, i), Cons.zero(sc))
					^ BOp.isBigger(VOp.getCoord(p2to1, i), Cons.zero(sc))){
				VOp.getCoord(v2, i).set(VOp.getCoord(p1to1, i));
			}
			else VOp.getCoord(v2, i).set(VOp.getCoord(p1to2, i));
		}
		
		p1to1.onUsed();
		p1to2.onUsed();
		p2to1.onUsed();
		p2to2.onUsed();
		
		return new ERectRange(p1.getDiffPos(v1), p1.getDiffPos(v2));
	}

}

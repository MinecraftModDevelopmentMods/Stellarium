package sciapi.api.value.euclidian;

import sciapi.api.posdiff.IAbsDiffSet;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.matrix.IMatrix;
import sciapi.api.value.matrix.IMatrixSet;
import sciapi.api.value.matrix.ITransformMatrixSet;
import sciapi.api.value.numerics.IReal;

public interface IEVecSet<E extends IEVector, C extends IValue>
	extends IAbsDiffSet<E, C> {

	/**Gives Dot Operator*/
	IBiOperator<C, E, E> opDot();
	
	/**Gives Size2 Operator, which gives the square of the size of the vector*/
	IUnaryOperator<C, E> size2();
	
	/**
	 * Gives Dimension of this vector set.
	 * */
	public int getDimension();
	
	/**
	 * get Nth Coordinate of the parameter Vector.
	 * @param N from 0 to Dimension-1
	 * */
	public C getCoord(IValRef<E> v, int N);
	
	
	/**
	 * get Matrix Set which contains Transformation Matrix of this vector set.
	 * */
	public ITransformMatrixSet getTransformMatrixSet();
	
	/**
	 * get New Instance of Matrix which contains Transformation Matrix of this vector set.
	 * @param toDim The dimension to transform to.
	 * */
	public ITransformMatrixSet getTransformMatrixSet(int toDim);
}

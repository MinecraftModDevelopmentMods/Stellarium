package sciapi.api.value.euclidian;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.absalg.VectorSpace;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.numerics.IScalarSet;

public abstract class AbsEVecSet<E extends IEVector<E, C>, C extends IValue>
 extends VectorSpace<E, C> implements IEVecSet<E, C> {

	protected int dim;
	
	public IBiOperator<C, E, E> dot;
	public IUnaryOperator<C, E> size;
	
	public AbsEVecSet(IScalarSet<C> pset, int pdim) {
		super(pset);
		
		dim = pdim;
	}

	@Override
	public IBiOperator<C, E, E> opDot() {
		return dot;
	}

	@Override
	public IUnaryOperator<C, E> size2() {
		return size;
	}

	@Override
	public int getDimension() {
		return dim;
	}

	@Override
	public C getCoord(IValRef<E> v, int N) {
		return v.getVal().getCoord(N);
	}

}

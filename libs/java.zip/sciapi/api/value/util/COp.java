package sciapi.api.value.util;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IAdditiveGroup;

public class COp {
	/** Gives Added value for AdditiveGroup Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> add(IValRef<V>... par)
	{
		IValRef<V> save = par[0].getParentSet().getSTemp();
		save.set(Cons.zero(save));
		
		for(IValRef<V> v : par)
			save = BOp.add(save, v);
		
		return save;
	}
	
	/** Gives Multiplicated value for Ring Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> mult(IValRef<V>... par)
	{
		IValRef<V> save = par[0].getParentSet().getSTemp();
		save.set(Cons.one(save));
		
		for(IValRef<V> v : par)
			save = BOp.mult(save, v);
		
		return save;
	}
}

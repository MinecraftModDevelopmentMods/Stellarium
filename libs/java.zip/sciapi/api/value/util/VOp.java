package sciapi.api.value.util;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IVectorSpace;
import sciapi.api.value.euclidian.IEVecSet;
import sciapi.api.value.euclidian.IEVector;
import sciapi.api.value.numerics.NumMath;

public class VOp {
	
	/**
	 * Gives Multiplicated value for VectorSpace Element.
	 * 
	 * @param par1 Scalar Value
	 * @param par2 VectorSpace Element
	 * */
	@Temporal
	public static <V extends IValue, C extends IValue> IValRef<V> mult(IValRef<C> par1, IValRef<V> par2)
	{
		if(par2.getParentSet() instanceof IVectorSpace)
		{
			IVectorSpace r = (IVectorSpace) par2.getParentSet();
			return r.opMult().calc(par1, par2);
		}
		
		throw new IllegalArgumentException("Non-Multiplicative Values: "+par1+", "+par2);
	}
	
	/**
	 * Gives Divided value for VectorSpace Element.
	 * 
	 * @param par1 Scalar Value
	 * @param par2 VectorSpace Element
	 * */
	@Temporal
	public static <V extends IValue, C extends IValue> IValRef<V> div(IValRef<C> par1, IValRef<V> par2)
	{
		if(par2.getParentSet() instanceof IVectorSpace)
		{
			IVectorSpace r = (IVectorSpace) par2.getParentSet();
			return r.opDiv().calc(par1, par2);
		}
		
		throw new IllegalArgumentException("Non-Multiplicative Values: "+par1+", "+par2);
	}
	
	

	/**
	 * Gives Dot product of Euclidian Vectors.
	 * */
	@Temporal
	public static <V extends IEVector> IValRef dot(IValRef<V> par1, IValRef<V> par2)
	{
		if(par2.getParentSet() instanceof IEVecSet)
		{
			IEVecSet r = (IEVecSet) par2.getParentSet();
			return r.opDot().calc(par1, par2);
		}
		
		throw new IllegalArgumentException("Unable to operate 'Dot' for vectors: "+par1+", "+par2);
	}

	/**
	 * Gives Normalized VectorSpace Element.
	 * */
	@Temporal
	public static <V extends IEVector> IValRef normalize(IValRef<V> par)
	{
		if(par.getParentSet() instanceof IEVecSet)
		{
			IEVecSet r = (IEVecSet) par.getParentSet();
			return r.opDiv().calc(size(par), par);
		}
		
		throw new IllegalArgumentException("Unable to normalize vector: "+par);
	}
	
	@Temporal
	public static <V extends IEVector> IValRef size2(IValRef<V> par)
	{
		if(par.getParentSet() instanceof IEVecSet)
		{
			IEVecSet r = (IEVecSet) par.getParentSet();
			return r.size2().calc(par);
		}
		
		throw new IllegalArgumentException("Invalid Vector: "+par);		
	}
	
	@Temporal
	public static <V extends IEVector> IValRef size(IValRef<V> par)
	{
		return NumMath.sqrt.calc(size2(par));
	}
	
	public static <V extends IEVector, C extends IValue> IValRef<C> getCoord(IValRef<V> par, int N)
	{
		return par.getVal().getCoord(N);
	}
	
	public static <V extends IEVector> int getDimension(IValRef<V> par)
	{
		return par.getVal().getDimension();
	}
}

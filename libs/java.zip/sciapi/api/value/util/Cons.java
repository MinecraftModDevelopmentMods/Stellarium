package sciapi.api.value.util;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IAdditiveGroup;
import sciapi.api.value.absalg.IRing;

public class Cons {
	
	/**Gives Zero, Identity of Addition from AdditiveGroup*/
	public static <V extends IValue> IValRef<V> zero(IAdditiveGroup<V> group)
	{
		return group.opAdd().identity();
	}
	
	/**Gives Zero, Identity of Addition from member*/
	public static <V extends IValue> IValRef<V> zero(IValRef<V> mem)
	{
		if(mem.getParentSet() instanceof IAdditiveGroup)
			return zero((IAdditiveGroup)mem.getParentSet());
		
		throw CommonExcLog.logError(new IllegalArgumentException("This set has no element 'zero' :"+mem.getParentSet()));
	}
	
	/**Gives One, Identity of Multiplication from Ring*/
	public static <V extends IValue> IValRef<V> one(IRing<V> ring)
	{
		return ring.opMult().identity();
	}
	
	/**Gives One, Identity of Multiplication from member*/
	public static <V extends IValue> IValRef<V> one(IValRef<V> mem)
	{
		if(mem.getParentSet() instanceof IRing)
			return one((IRing)mem.getParentSet());
		
		throw new IllegalArgumentException("This set has no element 'one' :"+mem.getParentSet());
	}
}

package sciapi.api.value.util;

import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.registry.PInterface;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IAdditiveGroup;
import sciapi.api.value.absalg.ICompSet;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.absalg.IRing;

public class BOp {
	
	/** Gives Added value for AdditiveGroup Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> add(IValRef<V> par1, IValRef<V> par2)
	{
		if(par1.getParentSet() instanceof IAdditiveGroup)
		{
			IAdditiveGroup g = (IAdditiveGroup) par1.getParentSet();
			return g.opAdd().calc(par1, par2);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Additive Values: "+par1+", "+par2));
	}
	
	/** Gives Subtracted value for AdditiveGroup Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> sub(IValRef<V> par1, IValRef<V> par2)
	{
		if(par1.getParentSet() instanceof IAdditiveGroup)
		{
			IAdditiveGroup g = (IAdditiveGroup) par1.getParentSet();
			return g.opSub().calc(par1, par2);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Additive Values: "+par1+", "+par2));
	}
	
	/** Gives Multiplicated value for Ring Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> mult(IValRef<V> par1, IValRef<V> par2)
	{
		if(par1.getParentSet() instanceof IRing)
		{
			IRing r = (IRing) par1.getParentSet();
			return r.opMult().calc(par1, par2);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Multiplicative Values: "+par1+", "+par2));
	}
	
	/** Gives Divided value for Field Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> div(IValRef<V> par1, IValRef<V> par2)
	{
		if(par1.getParentSet() instanceof IField)
		{
			IField f = (IField) par1.getParentSet();
			return f.opDiv().calc(par1, par2);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Multiplicative Values: "+par1+", "+par2));
	}
	
	
	/** Gives Minus (-) value for AdditiveGroup Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> minus(IValRef<V> par1)
	{
		if(par1.getParentSet() instanceof IAdditiveGroup)
		{
			IAdditiveGroup g = (IAdditiveGroup) par1.getParentSet();
			return g.opAdd().inverse(par1);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Additive Value: "+par1));
	}
	
	/** Gives Inverse (1/) value for Field Element. */
	@Temporal
	public static <V extends IValue> IValRef<V> inverse(IValRef<V> par1)
	{
		if(par1.getParentSet() instanceof IField)
		{
			IField g = (IField) par1.getParentSet();
			return g.opMult().inverse(par1);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Additive Value: "+par1));
	}
	
	/**Compares the two value. 1 for par1 > par2, -1 for par1 < par2, 0 otherwise*/
	public static <V extends IValue> int comp(IValRef<V> par1, IValRef<V> par2)
	{
		if(par1.getParentSet() instanceof ICompSet)
		{
			ICompSet g = (ICompSet) par1.getParentSet();
			return g.comp().compare(par1, par2);
		}
		
		throw CommonExcLog.logError(new IllegalArgumentException("Non-Comparable Value: "+par1));
	}
	
	/**Compares the two value. returns (par1 > par2)*/
	public static <V extends IValue> boolean isBigger(IValRef<V> par1, IValRef<V> par2)
	{
		return comp(par1, par2) > 0;
	}
	
	/**Compares the two value. returns (par1 == par2)*/
	public static <V extends IValue> boolean isSame(IValRef<V> par1, IValRef<V> par2)
	{
		return comp(par1, par2) == 0;
	}
}

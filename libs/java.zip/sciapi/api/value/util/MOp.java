package sciapi.api.value.util;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.matrix.IMatrix;

public class MOp {
	public static <V extends IMatrix, C extends IValue> IValRef<C> getElement(IValRef<V> par, int row, int col)
	{
		return par.getVal().getElement(row, col);
	}
	
	public static <V extends IMatrix> int getRowNum(IValRef<V> par)
	{
		return par.getVal().getRowNum();
	}
	
	public static <V extends IMatrix> int getColumnNum(IValRef<V> par)
	{
		return par.getVal().getColumnNum();
	}
}

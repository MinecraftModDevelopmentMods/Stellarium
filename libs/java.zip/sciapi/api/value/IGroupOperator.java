package sciapi.api.value;

import sciapi.api.temporaries.Temporal;

public interface IGroupOperator <V extends IValue> extends IBiOperator<V, V, V> {

	/**Gives the identity of this operator*/
	public IValRef<V> identity();
	
	/**Gives the inverse element of the par*/
	@Temporal
	public IValRef<V> inverse(IValRef<V> par);
}

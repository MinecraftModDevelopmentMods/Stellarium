package sciapi.api.value.matrix;

import sciapi.api.pinterface.LogLevel;
import sciapi.api.pinterface.def.DCException;
import sciapi.api.registry.PInterface;
import sciapi.api.value.euclidian.IEVector;


public class MatrixSizeException extends RuntimeException {
	public MatrixSizeException(IMatrix m1, IMatrix m2, String proc){
		super(MatrixtoExpr(m1) + " and " + MatrixtoExpr(m2)
				+ " have invalid size, so can't run this process: " + proc + ".\n");
		
		PInterface.getLogger().log(LogLevel.SEVERE,
				DCException.getCalcException("MatrixSizeException"),
				this.getMessage());
	}
	
	private static String MatrixtoExpr(IMatrix m){
		return m + "(" + m.getRowNum() + "," + m.getColumnNum() + ")";
	}
	
	private static String SettoExpr(IMatrixSet m){
		return m + "(" + m.getRowNum() + "," + m.getColumnNum() + ")";
	}
	
	public MatrixSizeException(IMatrix m, IEVector v, String proc){
		super(MatrixtoExpr(m) + " and " + v + "(" + v.getDimension() + ")"
				+ " have invalid size, so can't run this process: " + proc + ".\n");
		
		PInterface.getLogger().log(LogLevel.SEVERE,
				DCException.getCalcException("MatrixSizeException"),
				this.getMessage());
	}

	public MatrixSizeException(IMatrix m, IMatrixSet set, String proc) {
		super(MatrixtoExpr(m) + " doesn't belong to Matrix Set:" + SettoExpr(set)
				+ " so can't run this process: " + proc + ".\n");
		
		PInterface.getLogger().log(LogLevel.SEVERE,
				DCException.getCalcException("MatrixSizeException"),
				this.getMessage());
	}
}

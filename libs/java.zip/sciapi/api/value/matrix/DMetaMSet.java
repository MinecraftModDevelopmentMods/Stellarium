package sciapi.api.value.matrix;

import java.util.ArrayList;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.numerics.DDoubleSet;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.numerics.IScalarSet;
import sciapi.api.value.numerics.ScalarSet;

public class DMetaMSet implements IMetaMSet<DMatrixSet, DMatrix, IReal> {
	
	private ScalarSet scSet;
	
	private ArrayList<ArrayList<DMatrixSet>> matset
	 = new ArrayList<ArrayList<DMatrixSet>>(3);
	
	private IBiOperator<DMatrix, DMatrix, DMatrix> mmult;
	private IUnaryOperator<DMatrix, DMatrix> trp;
	
	public DMetaMSet(ScalarSet pscSet)
	{
		scSet = pscSet;
		
		mmult = new IBiOperator<DMatrix, DMatrix, DMatrix>() {

			@Override
			public IValRef<DMatrix> calc(IValRef<DMatrix> par1,
					IValRef<DMatrix> par2) {
				checkMatrixMultable(par1.getVal(), par2.getVal(), "matrixmult");
				
				DMatrixSet s1 = (DMatrixSet) par1.getParentSet();
				DMatrixSet s2 = (DMatrixSet) par2.getParentSet();
				DMatrixSet res = getSet(s1.getRowNum(), s2.getColumnNum());
				
				STempRef<DMatrix> temp = res.getSTemp();

				for(int i = 0; i < s1.getRowNum(); i++)
					for(int j = 0; j < s2.getColumnNum(); j++)
					{
						IReal el = res.getElement(temp, i, j);
						el.set(0.0);
						
						for(int k = 0; k < s1.getColumnNum(); k++)
							el.set(scSet.opAdd().calc(el,
									scSet.opMult().calc(s1.getElement(par1, i, k), s2.getElement(par2, k, j))));
					}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		trp = new IUnaryOperator<DMatrix, DMatrix>() {

			@Override
			public IValRef<DMatrix> calc(IValRef<DMatrix> par1) {
				DMatrixSet s1 = (DMatrixSet) par1.getParentSet();
				DMatrixSet s2 = getSet(s1.getColumnNum(), s1.getRowNum());
				
				STempRef<DMatrix> temp = s2.getSTemp();
				
				for(int i = 0; i < s2.getRowNum(); i++)
					for(int j = 0; j < s2.getColumnNum(); j++)
						s2.getElement(temp, i, j).set(s1.getElement(par1, j, i));
				
				par1.onUsed();
				
				return temp;
			}
			
		};
	}
	
	public IScalarSet<IReal> getScalarSet()
	{
		return scSet;
	}

	
	@Override
	public DMatrixSet getSet(int nrow, int ncol) {
		for(int i = matset.size(); i < nrow; i++)
		{
			matset.add(i, new ArrayList<DMatrixSet>(3));
		}
		
		ArrayList<DMatrixSet> subset = matset.get(nrow-1);
		
		for(int j = subset.size(); j < ncol; j++)
		{
			subset.add(j, new DMatrixSet(this, scSet, nrow, j+1));
		}
		
		return subset.get(ncol-1);
	}

	@Override
	public IBiOperator<DMatrix, DMatrix, DMatrix> opMmult() {
		return mmult;
	}

	@Override
	public IUnaryOperator<DMatrix, DMatrix> opTrp() {
		return trp;
	}
	
	
	private static void checkMatrixMultable(DMatrix p1, DMatrix p2, String proc){
		if(p1.getColumnNum() == p2.getRowNum())
			return;
		throw new MatrixSizeException(p1, p2, proc);
	}

}

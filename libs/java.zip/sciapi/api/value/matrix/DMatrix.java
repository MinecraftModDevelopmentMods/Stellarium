package sciapi.api.value.matrix;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.euclidian.EVector;
import sciapi.api.value.numerics.DDouble;
import sciapi.api.value.numerics.IReal;

/**Default Matrix that uses IReal.*/
public class DMatrix implements IMatrix<DMatrix, IReal> {

	private DMatrixSet par;
	
	private int nr, nc;
	
	private IReal value[][];
	
	/**
	 * Creates a Matrix as Zero Matrix using set.
	 * */
	public DMatrix(DMatrixSet ppar){
		par = ppar;
		nr = ppar.getRowNum();
		nc = ppar.getColumnNum();
		
		value = new DDouble[nr][nc];
		
		for(int i = 0; i < nr; i++)
			for(int j = 0; j < nc; j++)
				value[i][j] = new DDouble();
	}
	
	/**
	 * Creates a Matrix as Zero Matrix using dimensions.
	 * */
	public DMatrix(int pnr, int pnc){
		par = DMatrixSet.ins(pnr, pnc);
		nr = pnr;
		nc = pnc;
		
		value = new DDouble[nr][nc];
		for(int i = 0; i < nr; i++)
			for(int j = 0; j < nc; j++)
				value[i][j] = new DDouble();
	}
	
	@Override
	public boolean isZero() {
		for(IReal[] val : value)
			for(IReal v: val)
				if(v.asDouble() != 0.0)
					return false;
		return true;
	}

	@Override
	public IValSet<DMatrix> getParentSet() {
		return par;
	}

	@Override
	public void onUsed() { }

	@Override
	public DMatrix getVal() {
		return this;
	}

	@Override
	public DMatrix set(IValRef<DMatrix> val) {
		this.checkMatrixSame(val.getVal(), "set");
		
		for(int i = 0; i < nr; i++)
		{
			for(int j = 0; j < nc; j++)
				value[i][j].set(val.getVal().value[i][j]);
		}
		
		return this;
	}

	@Override
	public IReal getElement(int i, int j) {
		return value[i][j];
	}

	@Override
	public int getRowNum() {
		return nr;
	}

	@Override
	public int getColumnNum() {
		return nc;
	}
	
	public void checkMatrixSame(DMatrix p, String proc)
	{
		if(p.getRowNum() == nr && p.getColumnNum() == nc)
			return;
		throw new MatrixSizeException(p, this, proc);
	}
}

package sciapi.api.value.matrix;

import java.util.ArrayList;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.numerics.DDoubleSet;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.IScalarSet;
import sciapi.api.value.numerics.ScalarSet;

public class ZMetaMSet implements IMetaMSet<ZMatrixSet, ZMatrix, IInteger> {
	
	private ScalarSet scSet;
	
	private ArrayList<ArrayList<ZMatrixSet>> matset
	 = new ArrayList<ArrayList<ZMatrixSet>>(3);
	
	private IBiOperator<ZMatrix, ZMatrix, ZMatrix> mmult;
	private IUnaryOperator<ZMatrix, ZMatrix> trp;
	
	public ZMetaMSet(ScalarSet pscSet)
	{
		scSet = pscSet;
		
		mmult = new IBiOperator<ZMatrix, ZMatrix, ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<ZMatrix> par1,
					IValRef<ZMatrix> par2) {
				checkMatrixMultable(par1.getVal(), par2.getVal(), "matrixmult");
				
				ZMatrixSet s1 = (ZMatrixSet) par1.getParentSet();
				ZMatrixSet s2 = (ZMatrixSet) par2.getParentSet();
				ZMatrixSet res = getSet(s1.getRowNum(), s2.getColumnNum());
				
				STempRef<ZMatrix> temp = res.getSTemp();

				for(int i = 0; i < s1.getRowNum(); i++)
					for(int j = 0; j < s2.getColumnNum(); j++)
					{
						IInteger el = res.getElement(temp, i, j);
						el.set(0);
						
						for(int k = 0; k < s1.getColumnNum(); k++)
							el.set(scSet.opAdd().calc(el,
									scSet.opMult().calc(s1.getElement(par1, i, k), s2.getElement(par2, k, j))));
					}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		trp = new IUnaryOperator<ZMatrix, ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<ZMatrix> par1) {
				ZMatrixSet s1 = (ZMatrixSet) par1.getParentSet();
				ZMatrixSet s2 = getSet(s1.getColumnNum(), s1.getRowNum());
				
				STempRef<ZMatrix> temp = s2.getSTemp();
				
				for(int i = 0; i < s2.getRowNum(); i++)
					for(int j = 0; j < s2.getColumnNum(); j++)
						s2.getElement(temp, i, j).set(s1.getElement(par1, j, i));
				
				par1.onUsed();
				
				return temp;
			}
			
		};
	}
	
	public IScalarSet<IInteger> getScalarSet()
	{
		return scSet;
	}

	
	@Override
	public ZMatrixSet getSet(int nrow, int ncol) {
		for(int i = matset.size(); i < nrow; i++)
		{
			matset.add(i, new ArrayList<ZMatrixSet>(3));
		}
		
		ArrayList<ZMatrixSet> subset = matset.get(nrow-1);
		
		for(int j = subset.size(); j < ncol; j++)
		{
			subset.add(j, new ZMatrixSet(this, scSet, nrow, j+1));
		}
		
		return subset.get(ncol-1);
	}

	@Override
	public IBiOperator<ZMatrix, ZMatrix, ZMatrix> opMmult() {
		return mmult;
	}

	@Override
	public IUnaryOperator<ZMatrix, ZMatrix> opTrp() {
		return trp;
	}
	
	
	private static void checkMatrixMultable(ZMatrix p1, ZMatrix p2, String proc){
		if(p1.getColumnNum() == p2.getRowNum())
			return;
		throw new MatrixSizeException(p1, p2, proc);
	}

}

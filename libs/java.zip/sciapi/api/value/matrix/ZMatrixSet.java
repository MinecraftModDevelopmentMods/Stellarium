package sciapi.api.value.matrix;

import java.util.ArrayList;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.euclidian.EVecInt;
import sciapi.api.value.euclidian.EVecIntSet;
import sciapi.api.value.euclidian.EVector;
import sciapi.api.value.euclidian.EVectorSet;
import sciapi.api.value.numerics.DIntegerSet;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.ScalarSet;

public class ZMatrixSet extends AbsMatrixSet<ZMatrix, IInteger> implements
		ITransformMatrixSet<ZMatrix, EVecInt, IInteger> {

	private static ZMetaMSet matset = new ZMetaMSet(DIntegerSet.ins);
	
	public static ZMatrixSet ins(int row, int col)
	{
		return matset.getSet(row, col);
	}
	
	private ZMatrix zero;
	
	public ZMatrixSet(ZMetaMSet pmset, ScalarSet pset, int row, int col) {
		super(pmset, pset, row, col);
		
		zero = new ZMatrix(this);
		
		final ZMatrixSet ts = this;
		
		add = new IGroupOperator<ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<ZMatrix> par1,
					IValRef<ZMatrix> par2) {
				checkMatrix(par1.getVal(), "add");
				checkMatrix(par2.getVal(), "add");

				STempRef<ZMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opAdd().calc(ts.getElement(par1, i, j), ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<ZMatrix> identity() {
				return zero;
			}

			@Override
			public IValRef<ZMatrix> inverse(IValRef<ZMatrix> par) {
				checkMatrix(par.getVal(), "addinv");

				STempRef<ZMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opAdd().inverse(ts.getElement(par, i, j)));
				}
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<ZMatrix, ZMatrix, ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<ZMatrix> par1,
					IValRef<ZMatrix> par2) {
				checkMatrix(par1.getVal(), "sub");
				checkMatrix(par2.getVal(), "sub");

				STempRef<ZMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opSub().calc(ts.getElement(par1, i, j), ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IBiOperator<ZMatrix, IInteger, ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<IInteger> par1,
					IValRef<ZMatrix> par2) {
				checkMatrix(par2.getVal(), "add");

				STempRef<ZMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opMult().calc(par1, ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<ZMatrix, IInteger, ZMatrix>() {

			@Override
			public IValRef<ZMatrix> calc(IValRef<IInteger> par1,
					IValRef<ZMatrix> par2) {
				checkMatrix(par2.getVal(), "add");

				STempRef<ZMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opDiv().calc(ts.getElement(par2, i, j), par1));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
	}

	@Override
	public ZMatrix getNew() {
		return new ZMatrix(this);
	}

	@Override
	public IValRef<EVecInt> getTransformed(IValRef<ZMatrix> mat, IValRef<EVecInt> vec) {
		
		checkMatrix(mat.getVal(), "trasform");
		checkTransformable(mat.getVal(), vec.getVal());
		
		EVecIntSet vs = EVecIntSet.ins(nrow);
		STempRef<EVecInt> res = vs.getSTemp();
		
		for(int i = 0; i < nrow; i++)
		{
			vs.getCoord(res, i).set(0);
			for(int k = 0; k < ncol; k++)
			{
				vs.getCoord(res, i).set(
						scSet.opAdd().calc(vs.getCoord(res, i),
								scSet.opMult().calc(getElement(mat, i, k), vec.getVal().getCoord(k))));
			}
		}
		
		mat.onUsed();
		vec.onUsed();
		
		return res;
	}
	
	
	public void checkMatrix(ZMatrix p, String proc){
		if(p.getRowNum() == nrow && p.getColumnNum() == ncol)
			return;
		throw new MatrixSizeException(p, this, proc);
	}
	
	private static void checkMatrixMultable(ZMatrix p1, ZMatrix p2, String proc){
		if(p1.getColumnNum() == p2.getRowNum())
			return;
		throw new MatrixSizeException(p1, p2, proc);
	}
	
	private static void checkTransformable(ZMatrix p, EVecInt v){
		if(p.getColumnNum() == v.getDimension())
			return;
		throw new MatrixSizeException(p, v, "transformation");
	}

}

package sciapi.api.value.matrix;

import sciapi.api.value.IBiOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValue;
import sciapi.api.value.numerics.IScalarSet;

public interface IMetaMSet<S extends IMatrixSet, E extends IMatrix, C extends IValue> {
	
	/**Gives Matrix Set belongs to this Meta Matrix Set*/
	public S getSet(int nrow, int ncol);
	
	/**Gives the scalar set*/
	public IScalarSet<C> getScalarSet();
	
	/**Gives Matrix Multiplication Operator*/
	public IBiOperator<E,E,E> opMmult();
	
	/**Gives Matrix Transpose Operator*/
	public IUnaryOperator<E,E> opTrp();

}

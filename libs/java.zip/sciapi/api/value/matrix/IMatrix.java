package sciapi.api.value.matrix;

import sciapi.api.posdiff.IAbsDifference;
import sciapi.api.value.IValue;

/**
 * Matrix Interface.
 * */
public interface IMatrix<V extends IMatrix, S extends IValue> extends IAbsDifference<V> {

	/**
	 * get Element of this Matrix.
	 * 
	 * @param i row number.
	 * @param j column number.
	 * @return the Element.
	 * */
	public S getElement(int i, int j);
	
	
	/**
	 * get Row Number of this Matrix.
	 * */
	public int getRowNum();
	
	/**
	 * get Column Number of this Matrix.
	 * */
	public int getColumnNum();
}

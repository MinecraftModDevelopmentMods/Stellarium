package sciapi.api.value.matrix;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValSet;
import sciapi.api.value.euclidian.EVector;
import sciapi.api.value.numerics.DDouble;
import sciapi.api.value.numerics.DInteger;
import sciapi.api.value.numerics.IInteger;
import sciapi.api.value.numerics.IInteger;

/**Default Matrix that uses IInteger.*/
public class ZMatrix implements IMatrix<ZMatrix, IInteger> {

	private ZMatrixSet par;
	
	private int nr, nc;
	
	private IInteger value[][];
	
	/**
	 * Creates a Matrix as Zero Matrix using set.
	 * */
	public ZMatrix(ZMatrixSet ppar){
		par = ppar;
		nr = ppar.getRowNum();
		nc = ppar.getColumnNum();
		
		value = new DInteger[nr][nc];
		for(int i = 0; i < nr; i++)
			for(int j = 0; j < nc; j++)
				value[i][j] = new DInteger();
	}
	
	/**
	 * Creates a Matrix as Zero Matrix using dimensions.
	 * */
	public ZMatrix(int pnr, int pnc){
		par = ZMatrixSet.ins(pnr, pnc);
		nr = pnr;
		nc = pnc;
		
		value = new DInteger[nr][nc];
		for(int i = 0; i < nr; i++)
			for(int j = 0; j < nc; j++)
				value[i][j] = new DInteger();
	}
	
	@Override
	public boolean isZero() {
		for(IInteger[] val : value)
			for(IInteger v: val)
				if(v.asInt() != 0.0)
					return false;
		return true;
	}

	@Override
	public IValSet<ZMatrix> getParentSet() {
		return par;
	}

	@Override
	public void onUsed() { }

	@Override
	public ZMatrix getVal() {
		return this;
	}

	@Override
	public ZMatrix set(IValRef<ZMatrix> val) {
		this.checkMatrixSame(val.getVal(), "set");
		
		for(int i = 0; i < nr; i++)
		{
			for(int j = 0; j < nc; j++)
				value[i][j].set(val.getVal().value[i][j]);
		}
		
		return this;
	}

	@Override
	public IInteger getElement(int i, int j) {
		return value[i][j];
	}

	@Override
	public int getRowNum() {
		return nr;
	}

	@Override
	public int getColumnNum() {
		return nc;
	}
	
	public void checkMatrixSame(ZMatrix p, String proc)
	{
		if(p.getRowNum() == nr && p.getColumnNum() == nc)
			return;
		throw new MatrixSizeException(p, this, proc);
	}
}

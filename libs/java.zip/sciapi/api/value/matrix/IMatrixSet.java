package sciapi.api.value.matrix;

import sciapi.api.posdiff.IAbsDiffSet;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;

public interface IMatrixSet<E extends IMatrix, C extends IValue>
 extends IAbsDiffSet<E, C> {
	
	/**Gives Meta Matrix Set for this Set*/
	public IMetaMSet getMSet();
	
	/**Gives Row Number of this Matrix.*/
	public int getRowNum();
	
	/**Gives Column Number of this Matrix.*/
	public int getColumnNum();
	
	/**
	 * get Element of this Matrix.
	 * 
	 * @param i row number.
	 * @param j column number.
	 * @return the Element.
	 * */
	public C getElement(IValRef<E> v, int row, int col);
}

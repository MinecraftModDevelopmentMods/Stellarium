package sciapi.api.value.matrix;

import java.util.ArrayList;

import sciapi.api.temporaries.Temporal;
import sciapi.api.value.IBiOperator;
import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.STempRef;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.euclidian.EVector;
import sciapi.api.value.euclidian.EVectorSet;
import sciapi.api.value.numerics.DDoubleSet;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.numerics.ScalarSet;
import sciapi.api.value.util.Cons;

public class DMatrixSet extends AbsMatrixSet<DMatrix, IReal> implements
		ITransformMatrixSet<DMatrix, EVector, IReal> {

	private static DMetaMSet matset	= new DMetaMSet(DDoubleSet.ins);
	
	public static DMatrixSet ins(int row, int col)
	{
		return matset.getSet(row, col);
	}
	
	private DMatrix zero;
	
	public DMatrixSet(DMetaMSet pmset, ScalarSet pset, int row, int col) {
		super(pmset, pset, row, col);
		
		zero = new DMatrix(this);
		
		final DMatrixSet ts = this;
		
		add = new IGroupOperator<DMatrix>() {

			@Temporal
			@Override
			public IValRef<DMatrix> calc(IValRef<DMatrix> par1,
					IValRef<DMatrix> par2) {
				checkMatrix(par1.getVal(), "add");
				checkMatrix(par2.getVal(), "add");

				STempRef<DMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opAdd().calc(ts.getElement(par1, i, j), ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}

			@Override
			public IValRef<DMatrix> identity() {
				return zero;
			}

			@Temporal
			@Override
			public IValRef<DMatrix> inverse(IValRef<DMatrix> par) {
				checkMatrix(par.getVal(), "addinv");

				STempRef<DMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opAdd().inverse(ts.getElement(par, i, j)));
				}
				
				par.onUsed();
				
				return temp;
			}
			
		};
		
		sub = new IBiOperator<DMatrix, DMatrix, DMatrix>() {

			@Temporal
			@Override
			public IValRef<DMatrix> calc(IValRef<DMatrix> par1,
					IValRef<DMatrix> par2) {
				checkMatrix(par1.getVal(), "sub");
				checkMatrix(par2.getVal(), "sub");

				STempRef<DMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opSub().calc(ts.getElement(par1, i, j), ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		mult = new IBiOperator<DMatrix, IReal, DMatrix>() {

			@Temporal
			@Override
			public IValRef<DMatrix> calc(IValRef<IReal> par1,
					IValRef<DMatrix> par2) {
				checkMatrix(par2.getVal(), "add");

				STempRef<DMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opMult().calc(par1, ts.getElement(par2, i, j)));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
		
		div = new IBiOperator<DMatrix, IReal, DMatrix>() {

			@Temporal
			@Override
			public IValRef<DMatrix> calc(IValRef<IReal> par1,
					IValRef<DMatrix> par2) {
				checkMatrix(par2.getVal(), "add");

				STempRef<DMatrix> temp = getSTemp();
				
				for(int i = 0; i < nrow; i++)
				{
					for(int j = 0; j < ncol; j++)
						ts.getElement(temp, i, j).set(
							scSet.opDiv().calc(ts.getElement(par2, i, j), par1));
				}
				
				par1.onUsed();
				par2.onUsed();
				
				return temp;
			}
			
		};
	}

	@Override
	public DMatrix getNew() {
		return new DMatrix(this);
	}

	@Temporal
	@Override
	public IValRef<EVector> getTransformed(IValRef<DMatrix> mat, IValRef<EVector> vec) {
		
		checkMatrix(mat.getVal(), "trasform");
		checkTransformable(mat.getVal(), vec.getVal());
		
		EVectorSet vs = EVectorSet.ins(nrow);
		STempRef<EVector> res = vs.getSTemp();
		
		for(int i = 0; i < nrow; i++)
		{
			vs.getCoord(res, i).set(0.0);
			for(int k = 0; k < ncol; k++)
			{
				vs.getCoord(res, i).set(
						scSet.opAdd().calc(vs.getCoord(res, i),
								scSet.opMult().calc(getElement(mat, i, k), vec.getVal().getCoord(k))));
			}
		}
		
		mat.onUsed();
		vec.onUsed();
		
		return res;
		
	}
	
	
	public void checkMatrix(DMatrix p, String proc){
		if(p.getRowNum() == nrow && p.getColumnNum() == ncol)
			return;
		throw new MatrixSizeException(p, this, proc);
	}
	
	private static void checkTransformable(DMatrix p, EVector v){
		if(p.getColumnNum() == v.getDimension())
			return;
		throw new MatrixSizeException(p, v, "transformation");
	}

}

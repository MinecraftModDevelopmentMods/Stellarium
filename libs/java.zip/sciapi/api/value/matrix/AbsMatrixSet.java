package sciapi.api.value.matrix;

import sciapi.api.value.IGroupOperator;
import sciapi.api.value.IUnaryOperator;
import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IField;
import sciapi.api.value.absalg.VectorSpace;
import sciapi.api.value.numerics.IScalarSet;

public abstract class AbsMatrixSet<E extends IMatrix<E, C>, C extends IValue>
 extends VectorSpace<E, C> implements IMatrixSet<E, C> {

	protected IMetaMSet mset;
	
	protected int nrow;
	protected int ncol;
	
	public AbsMatrixSet(IMetaMSet pmset, IScalarSet<C> pset, int row, int col) {
		super(pset);
		
		mset = pmset;
		
		nrow = row;
		ncol = col;
	}
	
	@Override
	public IMetaMSet getMSet()
	{
		return mset;
	}

	@Override
	public int getRowNum() {
		return nrow;
	}

	@Override
	public int getColumnNum() {
		return ncol;
	}

	@Override
	public C getElement(IValRef<E> v, int row, int col) {
		return v.getVal().getElement(row, col);
	}

}

package sciapi.api.value.matrix;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;
import sciapi.api.value.euclidian.*;

public interface ITransformMatrixSet<T extends IMatrix,
V extends IEVector, S extends IValue> extends IMatrixSet<T, S> {
	
	/**
	 * Get the transformed Vector via this matrix.
	 * @param vec Vector to transformed.
	 * @return Transformed Vector.
	 * */
	public IValRef<V> getTransformed(IValRef<T> mat, IValRef<V> vec);
}

package sciapi.api.value;

public interface IValRef <V extends IValue> {
	
	/**Called when this reference is used, except for comparing.*/
	public void onUsed();
	
	/**Gives the value this reference is pointing*/
	public V getVal();
	
	/**Gives the parent set of the value this reference is pointing*/
	public IValSet<V> getParentSet();
	
	/**
	 * Substitute the value given reference is pointing for this value (reference)
	 * @return {@code this}
	 * */
	public V set(IValRef<V> val);
}

package sciapi.api.value;

import sciapi.api.abstraction.util.IProviderBase;
import sciapi.api.temporaries.TempUtil;
import sciapi.api.temporaries.Temporal;
import sciapi.api.value.numerics.DDouble;

public class STempProvider<V extends IValue> implements IProviderBase<STempRef<V>>{

	private TempUtil<STempRef<V>> temprov;
	private IValSet<V> pset;
	
	public STempProvider(IValSet<V> par)
	{
		temprov = new TempUtil<STempRef<V>>(this);
		pset = par;
	}
	
	@Temporal
	@Override
	public STempRef<V> getNew() {
		V val = pset.getNew();
		STempRef<V> tmp = new STempRef<V>();
		tmp.setVal(val);
		return tmp;
	}
	
	@Temporal
	public STempRef<V> getTemp() {
		STempRef<V> tmp = temprov.getTemp();
		return tmp;
	}
	
	public void release(STempRef<V> tmp) {
		temprov.release(tmp);
	}

}

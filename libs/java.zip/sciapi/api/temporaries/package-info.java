/**
 * 
 */
/**
 * 
 * This is the API which Maintains Temporary Values.
 * 
 * @author Astros
 *
 */

package sciapi.api.temporaries;

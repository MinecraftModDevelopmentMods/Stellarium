package sciapi.api.temporaries;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Annotation which indicates that it is related with temporal reference.
 * For method, this means the return type is temporal reference.
 * */
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
public @interface Temporal {

}

package sciapi.api.temporaries;

import sciapi.api.abstraction.util.IProviderBase;
import sciapi.api.storage.Pool;

public class TempUtil<T> {
	
	//Provides Temporary values.
	private ThreadLocal dt = new ThreadLocal();
	
	private IProviderBase<T> provider;
	
	public TempUtil(IProviderBase<T> pbase){
		provider = pbase;
	}
	
	public T getTemp()
	{
		Pool<T> d = (Pool<T>) dt.get();
		if (d == null)
		{
			d = new Pool<T>(5, 5, provider);
			dt.set(d);
		}
		
		return d.get();
	}
	public void release(T r){
		Pool<T> d = (Pool<T>) dt.get();
		if (d == null)
			return;
		d.remove(r);
	}
	
}

/**
 * 
 */
/**
 * 
 * Default Classes related to the data system.
 * 
 * @author Astros
 *
 */
package sciapi.api.def.data;
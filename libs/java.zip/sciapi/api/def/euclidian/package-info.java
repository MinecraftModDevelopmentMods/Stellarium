/**
 * 
 */
/**
 * /**
 * 
 * Default Classes related with Euclidian Space.
 * 
 * @author Astros
 *
 */

package sciapi.api.def.euclidian;

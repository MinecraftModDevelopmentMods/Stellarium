/**
 * 
 */
/**
 * 
 * Abstract interfaces for position
 * 
 * @author Astros
 *
 */

package sciapi.api.posdiff;

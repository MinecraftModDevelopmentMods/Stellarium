package sciapi.api.posdiff;

import sciapi.api.abstraction.util.IInsBase;

/**
 * Interface for Positioned Object.
 * */
public interface IPosObject<P extends IAbsPosition> {
	/**
	 * get the Position of this Object.
	 * */
	public P getPosition();
	
	/**
	 * get the World which this Object has belonged to.
	 * */
	public IWorld getWorld();
	
	/**
	 * Check if the Object has same position.
	 * */
	public boolean equals(Object o);
}

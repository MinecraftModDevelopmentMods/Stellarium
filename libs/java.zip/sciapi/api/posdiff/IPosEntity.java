package sciapi.api.posdiff;

import sciapi.api.abstraction.util.IInsBase;

public interface IPosEntity<E extends IPosEntity, R extends IAbsRange> extends IInsBase<E>{
	/**
	 * get the Position of this Object.
	 * */
	public R getRange();
	
	/**
	 * get the World which this Object has belonged to.
	 * */
	public IWorld getWorld();
}

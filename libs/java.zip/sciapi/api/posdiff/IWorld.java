package sciapi.api.posdiff;

import sciapi.api.abstraction.util.IProviderBase;

/**
 * Interface for World.
 * */
public interface IWorld extends IProviderBase<IAbsPosition> {

}

package sciapi.api.posdiff;

import sciapi.api.value.IValue;
import sciapi.api.value.absalg.IVectorSpace;

public interface IAbsDiffSet<E extends IAbsDifference, C extends IValue>
	extends IVectorSpace<E, C> { }

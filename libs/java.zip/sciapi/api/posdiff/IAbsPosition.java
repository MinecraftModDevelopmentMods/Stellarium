package sciapi.api.posdiff;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;

/**
 * Abstract Position Interface
 * */
public interface IAbsPosition<P extends IAbsPosition, D extends IAbsDifference> {
	
	/**
	 * Get Position which have the difference with original Position.
	 * if the Position is invalid, this method can return null.
	 * */
	public P getDiffPos(IValRef<D> diff);

	/**
	 * Get Difference from this Position to parameter Position.
	 * If the Difference is invalid, this method can return null.
	 * */
	public IValRef<D> getDifference(P pos);
	
	/**
	 * Check if it is equal Position.
	 * */
	abstract public boolean equals(Object o);
}

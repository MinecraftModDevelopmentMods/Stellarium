package sciapi.api.posdiff;

import sciapi.api.value.IValue;


/**
 * Abstract Difference Interface
 * */
public interface IAbsDifference<V extends IValue> extends IValue<V>{
	
	/**
	 * @return true if this difference is zero.
	 * */
	public boolean isZero();
}

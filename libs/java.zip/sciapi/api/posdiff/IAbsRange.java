package sciapi.api.posdiff;

import sciapi.api.value.IValRef;
import sciapi.api.value.IValue;

/**
 * Abstract Range Interface
 * */
public interface IAbsRange<R extends IAbsRange, P extends IAbsPosition> {

	/**
	 * Check if this Position is in Range.
	 * */
	public boolean inRange(P pos);
	
	/**
	 * Check if the range is Overlapped.
	 * */
	public boolean isOverlapped(R range);
	
	/**
	 * get Intersection of the ranges.
	 * returns null if there is no Intersection.
	 * */
	public R getIntersect(R range);
	
}

/**
 * 
 */
/**
 * 
 * Basis for Scientific APIs;
 * 
 * @author Astros
 *
 */
package sciapi.api.basis;

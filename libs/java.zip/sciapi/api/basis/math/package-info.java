/**
 * 
 */
/**
 * 
 * Basic Math APIs
 * 
 * @author Astros
 *
 */
package sciapi.api.basis.math;

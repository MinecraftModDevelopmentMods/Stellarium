package sciapi.api.basis;

import sciapi.api.mc.init.McSidedInit;
import cpw.mods.fml.relauncher.Side;

public class SciServerProxy extends SciCommonProxy {
	public void onPreInit(){
		super.onPreInit();
	}

	@Override
	public void onLoad() {
		super.onLoad();
	}

	@Override
	public void onPostInit() {
		super.onPostInit();
	}
}

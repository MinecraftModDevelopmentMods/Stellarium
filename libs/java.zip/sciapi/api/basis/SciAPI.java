package sciapi.api.basis;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import sciapi.api.basis.init.InitManager;
import sciapi.api.heat.HeatSystem;
import sciapi.api.mc.init.*;
import sciapi.api.mc.pinterface.McLogger;
import sciapi.api.registry.*;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.*;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.*;
import cpw.mods.fml.relauncher.Side;

@Mod(modid="sciapi", name="SciAPI", version="0.5.2")
public class SciAPI {
	@Instance(value = "sciapi")
	public static SciAPI instance;
    
	@SidedProxy(clientSide="sciapi.api.basis.SciClientProxy",
			serverSide="sciapi.api.basis.SciServerProxy")
	public static SciCommonProxy proxy;
    
	public static McLogger log;
	
	@EventHandler
    public void preInit(FMLPreInitializationEvent event) {
		log = new McLogger(event.getModLog());
		
		InitManager.Init();
		McUnivInit.Init();
		proxy.onPreInit();
		
		Configuration cfg = new Configuration(event.getSuggestedConfigurationFile());
		
		cfg.load();
		
		PInterface.scifilter.debugEnabled = cfg.get("Logging", "DebugEnabled", true).getBoolean();
		PInterface.scifilter.poolingEnabled = cfg.get("Logging", "PoolingEnabled", true).getBoolean();
		
		cfg.save();

    }
    
    @EventHandler
    public void load(FMLInitializationEvent event) {
    	proxy.onLoad();
    }
    
    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
    	proxy.onPostInit();
    }
    
    
	@EventHandler
	public void serverLoad(FMLServerStartingEvent event) {
		McManagerRegistry.onLoad(Side.SERVER);
	}
	
	@EventHandler
	public void serverUnload(FMLServerStoppingEvent event) {
		McManagerRegistry.onUnload(Side.SERVER);
	}
}

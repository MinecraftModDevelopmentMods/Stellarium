package sciapi.api.basis.data;

public class TagObject {
	public TagObject(IDataTag ptag, Object pobj){
		tag = ptag;
		obj = pobj;
	}
	
	public IDataTag tag;
	public Object obj;
}

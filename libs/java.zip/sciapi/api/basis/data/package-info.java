/**
 * 
 */
/**
 * 
 * Provides Basic Data Structures, etc.
 * 
 * @author Astros
 *
 */
package sciapi.api.basis.data;

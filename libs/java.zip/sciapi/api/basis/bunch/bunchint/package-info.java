/**
 * 
 */
/**
 * 
 * Provides 'Bunch', which is similar with Stacks(ItemStack, FluidStack, etc.)
 * with the amount is integer.
 * This is for creating new 'Bunch' easily.
 * 
 * @author Astros
 *
 */
package sciapi.api.basis.bunch.bunchint;

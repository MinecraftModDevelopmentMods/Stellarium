package sciapi.api.basis.bunch.bunchint;

public interface IBunchIntIdManager {
	public IBunchIntIdType getType(int id);
}

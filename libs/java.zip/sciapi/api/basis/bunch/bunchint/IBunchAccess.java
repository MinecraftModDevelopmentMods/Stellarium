package sciapi.api.basis.bunch.bunchint;

public interface IBunchAccess {
	
}

/**
 * 
 */
/**
 * 
 * For Initializations.
 * 
 * @author Astros
 *
 */
package sciapi.api.basis.init;

/**
 * 
 */
/**
 * 
 * Data System for minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.data;
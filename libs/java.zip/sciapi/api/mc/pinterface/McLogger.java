package sciapi.api.mc.pinterface;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;

import cpw.mods.fml.common.FMLLog;
import sciapi.api.pinterface.ICategory;
import sciapi.api.pinterface.ILogger;
import sciapi.api.pinterface.IStrMessage;
import sciapi.api.pinterface.LogLevel;
import sciapi.api.pinterface.def.CommonExcLog;
import sciapi.api.pinterface.def.DCException;
import sciapi.api.registry.PInterface;

/**This is Logger for SciAPI's Minecraft Version.*/
public class McLogger implements ILogger {
	
	public Logger log;
	
	public McLogger(Logger plog)
	{
		log = plog;
	}
	
	@Override
	public void log(LogLevel lev, ICategory ca, String con) {
		log.log(getLevel(lev), "[" + ca.getName() + "]: " + con);
	}

	@Override
	public void log(LogLevel lev, ICategory ca, IStrMessage msg) {
		log.log(getLevel(lev), "[" + ca.getName() + "]: " + msg.getContext());
	}
	
	public static Level getLevel(LogLevel lev)
	{
		if(lev == LogLevel.DEBUG)
			return Level.DEBUG;
		else if(lev == LogLevel.ERROR)
			return Level.ERROR;
		else if(lev == LogLevel.INFO)
			return Level.INFO;
		else if(lev == LogLevel.SEVERE)
			return Level.FATAL;
		else if(lev == LogLevel.WARNING)
			return Level.WARN;
		
		//This line would not run.
		return Level.ALL;
	}

}

/**
 * 
 */
/**
 * 
 * Application of PInterface for Minecraft
 * 
 * @author Abastro
 *
 */
package sciapi.api.mc.pinterface;
/**
 * 
 */
/**
 * 
 * For Inventories of Minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.inventory;
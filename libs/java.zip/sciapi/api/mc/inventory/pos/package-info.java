/**
 * 
 */
/**
 * 
 * Specific Application of Positions & World for Minecraft Inventory.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.inventory.pos;
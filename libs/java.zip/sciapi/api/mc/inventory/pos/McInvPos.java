package sciapi.api.mc.inventory.pos;

import net.minecraft.item.ItemStack;
import sciapi.api.mc.pos.McWorldPos;
import sciapi.api.posdiff.*;
import sciapi.api.temporaries.TempUtil;
import sciapi.api.value.IValRef;
import sciapi.api.value.euclidian.EVecInt;
import sciapi.api.value.euclidian.EVecIntSet;
import sciapi.api.value.euclidian.EVectorSet;

/**
 * 2D Position for Inventory.
 * */
public class McInvPos implements IAbsPosition<McInvPos, EVecInt> {
	
	public static final EVecIntSet set = EVecIntSet.ins(2);
	
	public McInvWorld iworld;
	public EVecInt vec = set.getNew();
	
	public McInvPos() { }
	
	public McInvPos(McInvWorld piworld, EVecInt ppos){
		iworld = piworld;
		vec.set(ppos);
	}

	@Override
	public McInvPos getDiffPos(IValRef<EVecInt> diff) {
		diff.onUsed();
		
		McInvPos pos = new McInvPos();
		pos.iworld = iworld;
		pos.vec.set(set.opAdd().calc(vec, diff));
		
		return pos;
	}

	@Override
	public IValRef<EVecInt> getDifference(McInvPos pos) {
		if(!this.iworld.equals(pos.iworld))
			return null;
		
		return set.opSub().calc(pos.vec, this.vec);
	}
	
	public McInvPos set(McInvWorld pworld, IValRef<EVecInt> v){
		iworld = pworld;
		
		if(v == null)
			vec = new EVecInt(0,0);
		else if(vec == null){
			vec = new EVecInt(0,0);
			vec.set(v);
		}
		else vec.set(v);
		
		v.onUsed();
		
		return this;
	}

	public McInvPos set(McInvPos par) {
		this.iworld = par.iworld;
		this.vec.set(par.vec);
		
		return this;
	}
	
	
	public ItemStack getItemStack(){
		return iworld.getItemStack(vec);
	}
	
	
	@Override
	public boolean equals(Object o){
		if(o instanceof McInvPos){
			McInvPos w = (McInvPos)o;
			return iworld.equals(w.iworld) && vec.equals(w.vec);
		}
		return false;
	}
	
	@Override
	public int hashCode(){
		return iworld.toEntry(vec);
	}
}

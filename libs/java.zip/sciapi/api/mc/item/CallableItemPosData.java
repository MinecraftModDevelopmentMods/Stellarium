package sciapi.api.mc.item;

import java.util.concurrent.Callable;

import sciapi.api.value.euclidian.EVecInt;

public class CallableItemPosData implements Callable {

    final ItemEntity theItemEntity;
	
	public CallableItemPosData(ItemEntity par1TileEntity)
	{
        this.theItemEntity = par1TileEntity;
	}
	
    public String callItemPos()
    {
    	EVecInt vec = theItemEntity.pos.vec;
        return "(" + vec.getCoord(0) + ", " + vec.getCoord(1) + ")";
    }

	@Override
	public Object call() throws Exception {
		return callItemPos();
	}

}

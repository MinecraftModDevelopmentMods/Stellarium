/**
 * 
 */
/**
 * 
 * API on MultiItem Structures for Minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.item.multiitem;
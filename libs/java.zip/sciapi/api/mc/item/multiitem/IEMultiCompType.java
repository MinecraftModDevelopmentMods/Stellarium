package sciapi.api.mc.item.multiitem;

import sciapi.api.mc.item.ItemEntity;

public interface IEMultiCompType {
	public boolean match(ItemEntity ie);
}

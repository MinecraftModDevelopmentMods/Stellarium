/**
 * 
 */
/**
 * 
 * API related with Tick of Minecraft.
 * @author Astros
 *
 */
package sciapi.api.mc.tick;
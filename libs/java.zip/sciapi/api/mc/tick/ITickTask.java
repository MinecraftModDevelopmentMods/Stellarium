package sciapi.api.mc.tick;

public interface ITickTask extends ITickStartTask, ITickEndTask {

}

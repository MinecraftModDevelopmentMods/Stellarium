package sciapi.api.mc.tick;

public interface ITickTaskBase {

}

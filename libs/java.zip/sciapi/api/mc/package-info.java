/**
 * 
 */
/**
 * 
 * Specific Application for Minecraft!
 * 
 * @author Astros
 *
 */
package sciapi.api.mc;

/**
 * 
 */
/**
 * 
 * For initializations related with minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.init;
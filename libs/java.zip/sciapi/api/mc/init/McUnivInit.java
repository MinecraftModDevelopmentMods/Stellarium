package sciapi.api.mc.init;

import sciapi.api.basis.SciAPI;
import sciapi.api.basis.SciConnectionHandler;
import sciapi.api.mc.unit.McUnitInit;
import sciapi.api.registry.PInterface;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.relauncher.Side;

public class McUnivInit {
	public static void Init(){
		McUnitInit.Init();
		
		FMLCommonHandler.instance().bus().register(new SciConnectionHandler());
		PInterface.registerLogger("Mc", SciAPI.log);
	}
}

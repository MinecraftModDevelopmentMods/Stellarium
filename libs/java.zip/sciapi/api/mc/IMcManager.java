package sciapi.api.mc;

public interface IMcManager {
	public void onLoad();
	public void onUnload();
}

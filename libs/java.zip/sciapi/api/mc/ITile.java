package sciapi.api.mc;

import sciapi.api.mc.pos.McWorldPos;
import sciapi.api.posdiff.IPosObject;
import sciapi.api.value.euclidian.EVecInt;

/**
 * for Tiles
 * */
public interface ITile extends IPosObject<McWorldPos> {
}

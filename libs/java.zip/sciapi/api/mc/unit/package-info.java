/**
 * 
 */
/**
 * 
 * Specific Application of Units for Minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.unit;
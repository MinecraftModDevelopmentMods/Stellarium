package sciapi.api.mc.pos;

import sciapi.api.posdiff.IAbsDifference;
import sciapi.api.posdiff.IAbsPosition;
import sciapi.api.registry.TickTaskRegistry;
import sciapi.api.storage.Pool;
import sciapi.api.temporaries.TempUtil;
import sciapi.api.value.IValRef;
import sciapi.api.value.euclidian.EVecInt;
import sciapi.api.value.euclidian.EVecIntSet;

/**
 * Positions for World!
 * */
public class McWorldPos implements IAbsPosition<McWorldPos, EVecInt>{
	
	public int dimension;
	public EVecInt vec;
	public static EVecIntSet set = EVecIntSet.ins(3);
	
	private static TempUtil tu = new TempUtil(McWorld.instance());

	
	public McWorldPos(){
		dimension = 0;
		vec = set.getNew();
	}
	
	public McWorldPos(int pdim, EVecInt pvec){
		dimension = pdim;
		vec.set(pvec);
	}


	@Override
	public McWorldPos getDiffPos(IValRef<EVecInt> diff) {
		McWorldPos w = new McWorldPos();
		w.dimension = this.dimension;
		w.vec.set(set.opAdd().calc(vec, diff));
		
		return w;
	}

	@Override
	public EVecInt getDifference(McWorldPos pos) {
		if(this.dimension != pos.dimension)
			return null;
		
		return set.getNew().set(set.opSub().calc(pos.vec, vec));
	}
	
	
	public static McWorldPos getTemp(){
		return (McWorldPos) tu.getTemp();
	}
	
	
	public McWorldPos set(int pdim, int x, int y, int z){
		dimension = pdim;
		vec.set(x, y, z);
		
		return this;
	}
	
	public McWorldPos set(int pdim, EVecInt v){
		dimension = pdim;
		
		if(v == null)
			vec = new EVecInt(0,0,0);
		else vec.set(v);
		
		return this;
	}
	
	
	@Override
	public boolean equals(Object o){
		if(o instanceof McWorldPos){
			McWorldPos w = (McWorldPos)o;
			return dimension == w.dimension && vec.equals(w.vec);
		}
		
		return false;
	}
}

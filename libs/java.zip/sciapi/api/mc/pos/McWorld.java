package sciapi.api.mc.pos;

import sciapi.api.heat.HeatSystem;
import sciapi.api.posdiff.*;
import sciapi.api.value.euclidian.*;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;

public class McWorld implements IDiscreteWorld<McWorldPos, EVecInt>{
	
	private static McWorld mc = new McWorld();
	
	public static McWorld instance(){
		return mc;
	}

	@Override
	public IPosObject getObjonPos(McWorldPos pos) {
		World worldObj = DimensionManager.getWorld(pos.dimension);
		
		TileEntity te = worldObj.getTileEntity(pos.vec.getCoord(0).asInt(),
				pos.vec.getCoord(1).asInt(),
				pos.vec.getCoord(2).asInt());
		
		if(te == null || !(te instanceof IPosObject)){
			return null;
		}
		
		return (IPosObject)te;
	}

	@Override
	public IDirection<EVecInt>[] getPossibleDirections() {
		return McDirection.getAlldirs();
	}

	@Override
	public boolean equals(Object o){
		if(o instanceof McWorld)
			return true;
		return false;
	}

	@Override
	public IAbsPosition getNew() {
		return new McWorldPos();
	}

}

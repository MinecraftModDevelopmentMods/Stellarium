/**
 * 
 */
/**
 * 
 * Specific Application of Positions & World for Minecraft.
 * 
 * @author Astros
 *
 */
package sciapi.api.mc.pos;
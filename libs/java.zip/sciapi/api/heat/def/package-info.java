/**
 * 
 */
/**
 * 
 * Default classes for Heat.
 * 
 * @author Astros
 *
 */
package sciapi.api.heat.def;

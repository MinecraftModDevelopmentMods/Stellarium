/**
 * 
 */
/**
 * 
 * Heat API for Minecraft.
 * Simulates Heat between Heat Components!
 * 
 * @author Astros
 *
 */
package sciapi.api.heat;

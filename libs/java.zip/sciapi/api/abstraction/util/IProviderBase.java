package sciapi.api.abstraction.util;

public interface IProviderBase<T> {
	
	/**
	 * get New Instance of the type.
	 * 
	 * @return new Instance of this type.
	 * */
	public T getNew();
	
}

/**
 * 
 */
/**
 * 
 * Abstraction Utilities
 * 
 * @author Astros
 *
 */

package sciapi.api.abstraction.util;

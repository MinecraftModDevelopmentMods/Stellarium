package sciapi.api.abstraction.util;

public interface ICalcUtil <U extends ICalcUtil, T extends IInsBase> extends IExUtil<U,T> {	

}

package sciapi.api.abstraction.util;

public interface IInsBase<T extends IInsBase> extends IProviderBase<T> {
	
	/**
	 * set this object as the parameter.
	 * 
	 * @param par the parameter
	 * @return <code>this</code>
	 * */
	public T set(T par);
}

package sciapi.api.test;

import sciapi.api.value.IValRef;
import sciapi.api.value.euclidian.CrossUtil;
import sciapi.api.value.euclidian.EReflect;
import sciapi.api.value.euclidian.ERotate;
import sciapi.api.value.euclidian.EVector;
import sciapi.api.value.euclidian.EVectorSet;
import sciapi.api.value.numerics.IReal;
import sciapi.api.value.util.VOp;

public class ValTest {

	public static void valTest()
	{
		ValTest vt = new ValTest();
		
		Thread th = new Thread(new Runnable() {

			@Override
			public void run() {
				ValTest vt2 = new ValTest();
				
				for(int i = 0; i < 100; i++)
					vt2.test();
			}
			
		});
		
		th.run();
		
		for(int i = 0; i < 100; i++)
			vt.test();
	}
	
	public void test()
	{
		EVector vec = new EVector(1.0, 0.0, 0.0);
		EVector v2 = new EVector(0.0, 1.0, 0.0);
		EVector v3 = new EVector(1.0, 1.0, 1.0);
		
		EReflect ref = new EReflect(v3, false);
		ERotate rot = new ERotate(vec, v2, false);
		rot.setAngle(Math.PI / 2);
		
		vec.set(CrossUtil.cross(vec, v2));
		vec.set(ref.transform(vec));
		vec.set(rot.transform(vec));
		
		IValRef<IReal> r = VOp.size(vec);
		
		double val = r.getVal().asDouble();
		
		if(val < 0.8 || val > 1.2)
		{
			System.err.println("ERROR! Some Calc Glitch Happened!");
		}
		
		r.onUsed();
	}
	
}

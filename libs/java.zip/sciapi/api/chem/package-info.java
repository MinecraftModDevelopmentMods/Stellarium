/**
 * 
 */
/**
 * 
 * Chemical API for Minecraft.
 * Manage Chemical Compounds for scientific materials!
 * 
 * @author Astros
 *
 */
package sciapi.api.chem;
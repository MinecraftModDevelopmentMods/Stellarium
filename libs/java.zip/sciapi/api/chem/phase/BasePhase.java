package sciapi.api.chem.phase;

public enum BasePhase {
	Solid,
	Liquid,
	Gas
}

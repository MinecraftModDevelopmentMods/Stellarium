/**
 * 
 */
/**
 * 
 * Phase related objects for the Chemical API.
 * 
 * @author Astros
 *
 */
package sciapi.api.chem.phase;
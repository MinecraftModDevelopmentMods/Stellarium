/**
 * 
 */
/**
 * 
 * Element part of the Chemical API.
 * 
 * @author Astros
 *
 */
package sciapi.api.chem.elem;
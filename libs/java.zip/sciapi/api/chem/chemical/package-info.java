/**
 * 
 */
/**
 * 
 * Chemical part of the Chemical API.
 * 
 * @author Astros
 *
 */
package sciapi.api.chem.chemical;
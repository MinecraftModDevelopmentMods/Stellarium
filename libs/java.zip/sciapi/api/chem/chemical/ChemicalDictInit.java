package sciapi.api.chem.chemical;

public class ChemicalDictInit {
	public static void Init(ChemicalDictionary dic){
		
	}
}

package abr.heatcraft.itementity;

import abr.heatcraft.core.InventoryIECrafting;
import abr.heatcraft.item.ItemLiquidTank;
import abr.heatcraft.recipes.CastingRecipes;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fluids.FluidContainerRegistry;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.IFluidContainerItem;
import net.minecraftforge.fluids.ItemFluidContainer;
import sciapi.api.mc.inventory.pos.McInvDirection;
import sciapi.api.mc.inventory.pos.McInvPos;
import sciapi.api.mc.inventory.pos.McInvWorld;
import sciapi.api.mc.item.ItemEntity;
import sciapi.api.mc.pos.McWorld;
import sciapi.api.mc.pos.McWorldPos;
import sciapi.api.value.euclidian.EVecInt;

public class IECrafter extends ItemEntity {
	
	int delay = 0;
	CraftingManager crf = CraftingManager.getInstance();
	InventoryIECrafting inv;
	
	public IECrafter() {
		super();
	}
	
	@Override
	public void updateEntity()
	{
		if(!worldObj.isRemote && worldObj.getItemStack(pos) != null)
		{
			EVecInt left = McInvDirection.LEFT.toDifference();
			EVecInt up = McInvDirection.UP.toDifference();
			EVecInt down = McInvDirection.DOWN.toDifference();
			
			McInvPos cen = pos.getDiffPos(left).getDiffPos(left);
			
			McInvPos crafts[] = new McInvPos[9];
			McInvPos temp;
			
			for(int i = -1; i <= 1; i++)
				for(int j = -1; j <= 1; j++)
				{
					crafts[(i+1) + (j+1) * 3] = cen.getDiffPos(new EVecInt(i, j));
				}
			
			if(worldObj.toEntry(crafts[8].vec) >= worldObj.inv.getSizeInventory())
				return;
			if(worldObj.toEntry(crafts[0].vec) < 0)
				return;
			
			inv = new InventoryIECrafting(crafts, 3, 3);
			
			
			EVecInt dvec = McInvDirection.RIGHT.toDifference();
			McInvPos next = pos.getDiffPos(dvec);
			
			ItemStack to = worldObj.getItemStack(next);
			ItemStack res = crf.findMatchingRecipe(inv, DimensionManager.getWorld(0));
			
			if(res == null)
				return;
			
			if(to != null)
			{
				if(!to.isItemEqual(res))
					return;
				int max = to.getMaxStackSize();
				if(res.stackSize <= 0 || (to.stackSize + res.stackSize) > max)
					return;
			}
			
			delay++;
			
			McInvWorld.getIECompound(worldObj.getItemStack(pos))
			.setInteger("maxprog", 30);
			McInvWorld.getIECompound(worldObj.getItemStack(pos))
			.setInteger("progress", 30-delay);
			
			if(delay >= 30)
			{
				delay = 0;
				
				inv.decline();
				inv.apply();
				
				if(to == null)
					worldObj.setItemStack(next, res);
				else to.stackSize += res.stackSize;
			}
		}
	}

}

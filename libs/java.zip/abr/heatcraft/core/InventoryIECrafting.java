package abr.heatcraft.core;

import sciapi.api.mc.inventory.pos.McInvPos;
import sciapi.api.mc.inventory.pos.McInvWorld;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;

public class InventoryIECrafting extends InventoryCrafting {

	private McInvWorld par;
	private McInvPos[] poses;
	private ItemStack[] stacks;
	
	public InventoryIECrafting(McInvPos[] pos, int w, int h)
	{
		super(null, h, w);
		stacks = new ItemStack[w * h];
		par = pos[0].iworld;
		poses = pos;
		
		for(int i = 0; i < this.getSizeInventory(); i++)
			this.setInventorySlotContents(i, par.getItemStack(poses[i]));
	}
	
	public void decline()
	{
        for (int i = 0; i < this.getSizeInventory(); ++i)
        {
            ItemStack itemstack1 = this.getStackInSlot(i);

            if (itemstack1 != null)
            {
                this.decrStackSize(i, 1);

                if (itemstack1.getItem().hasContainerItem(itemstack1))
                {
                    ItemStack itemstack2 = itemstack1.getItem().getContainerItem(itemstack1);

                    if (!itemstack1.getItem().doesContainerItemLeaveCraftingGrid(itemstack1))
                    {
                        if (this.getStackInSlot(i) == null)
                        {
                            this.setInventorySlotContents(i, itemstack2);
                        }
                    }
                }
            }
        }
	}
	
	public void apply()
	{
		for(int i = 0; i < this.getSizeInventory(); i++)
			par.setItemStack(poses[i], this.getStackInSlot(i));
	}
	
    /**
     * Returns the number of slots in the inventory.
     */
    public int getSizeInventory()
    {
        return this.stacks.length;
    }

    /**
     * Returns the stack in slot i
     */
    public ItemStack getStackInSlot(int p_70301_1_)
    {
        return p_70301_1_ >= this.getSizeInventory() ? null : this.stacks[p_70301_1_];
    }
    
    /**
     * Returns the name of the inventory
     */
    public String getInventoryName()
    {
        return "container.iecrafting";
    }

    /**
     * When some containers are closed they call this on each slot, then drop whatever it returns as an EntityItem -
     * like when you close a workbench GUI.
     */
    public ItemStack getStackInSlotOnClosing(int p_70304_1_)
    {
        return this.getStackInSlot(p_70304_1_);
    }

    /**
     * Removes from an inventory slot (first arg) up to a specified number (second arg) of items and returns them in a
     * new stack.
     */
    public ItemStack decrStackSize(int p_70298_1_, int p_70298_2_)
    {
        if (this.stacks[p_70298_1_] != null)
        {
            ItemStack itemstack;

            if (this.stacks[p_70298_1_].stackSize <= p_70298_2_)
            {
                itemstack = this.stacks[p_70298_1_];
                this.stacks[p_70298_1_] = null;
                return itemstack;
            }
            else
            {
                itemstack = this.stacks[p_70298_1_].splitStack(p_70298_2_);

                if (this.stacks[p_70298_1_].stackSize == 0)
                {
                    this.stacks[p_70298_1_] = null;
                }

                return itemstack;
            }
        }
        else
        {
            return null;
        }
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void setInventorySlotContents(int p_70299_1_, ItemStack p_70299_2_)
    {
        this.stacks[p_70299_1_] = p_70299_2_;
    }
}

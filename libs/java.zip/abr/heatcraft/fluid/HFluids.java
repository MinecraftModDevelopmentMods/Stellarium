package abr.heatcraft.fluid;

import abr.heatcraft.item.HItems;
import abr.heatcraft.item.ItemLiquidTank;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.IIcon;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;

public class HFluids {
	
	public static Fluid liqiron, liqoreiron;
	
	public static Fluid liqgold, liqoregold;

	public static Fluid liqcopper, liqorecopper;

	public static Fluid liqtin, liqoretin;
	
	public static Fluid liqlead, liqorelead;
	
	public static Fluid liqsilver, liqoresilver;
	
	public static IIcon iron, tin, lead, silver, gold, copper;

	
	public static void Init(){
		liqiron = new MetalFluid("liqiron");
		liqgold = new MetalFluid("liqgold");
		liqcopper = new MetalFluid("liqcopper");
		liqtin = new MetalFluid("liqtin");
		liqlead = new MetalFluid("liqlead");
		liqsilver = new MetalFluid("liqsilver");
		
		liqoreiron = new OreFluid("liqoreiron");
		liqoregold = new OreFluid("liqoregold");
		liqorecopper = new OreFluid("liqorecopper");
		liqoretin = new OreFluid("liqoretin");
		liqorelead = new OreFluid("liqorelead");
		liqoresilver = new OreFluid("liqoresilver");
		
		FluidRegistry.registerFluid(liqiron);
		FluidRegistry.registerFluid(liqgold);
		FluidRegistry.registerFluid(liqcopper);
		FluidRegistry.registerFluid(liqtin);
		FluidRegistry.registerFluid(liqlead);
		FluidRegistry.registerFluid(liqsilver);
		
		FluidRegistry.registerFluid(liqoreiron);
		FluidRegistry.registerFluid(liqoregold);
		FluidRegistry.registerFluid(liqorecopper);
		FluidRegistry.registerFluid(liqoretin);
		FluidRegistry.registerFluid(liqorelead);
		FluidRegistry.registerFluid(liqoresilver);
	}
	
	@SideOnly(Side.CLIENT)
	public static void onTextureInit(TextureMap map)
	{
		liqiron.setIcons(iron);
		liqgold.setIcons(gold);
		liqcopper.setIcons(copper);
		liqtin.setIcons(tin);
		liqlead.setIcons(lead);
		liqsilver.setIcons(silver);
		
		liqoreiron.setIcons(iron);
		liqoregold.setIcons(gold);
		liqorecopper.setIcons(copper);
		liqoretin.setIcons(tin);
		liqorelead.setIcons(lead);
		liqoresilver.setIcons(silver);
	}
}

package abr.heatcraft.fluid;

import net.minecraftforge.fluids.Fluid;

public class OreFluid extends Fluid {

	public OreFluid(String fluidName) {
		super(fluidName);
	}

}

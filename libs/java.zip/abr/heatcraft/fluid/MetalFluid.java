package abr.heatcraft.fluid;

import net.minecraftforge.fluids.Fluid;

public class MetalFluid extends Fluid {

	public MetalFluid(String fluidName) {
		super(fluidName);
	}

}

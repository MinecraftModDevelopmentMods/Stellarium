package abr.heatcraft.recipes;

import java.util.*;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;

public class CastingRecipes {
	
	private static CastingRecipes castrec = new CastingRecipes();
	
	private Map<Integer, ItemStack> casting = new HashMap();
	private Map<Integer, FluidStack> copr = new HashMap();
	
	public static CastingRecipes instance()
	{
		return castrec;
	}
	
	public void addCasting(Fluid fluid, ItemStack stack)
	{
		casting.put(Integer.valueOf(fluid.getID()), stack);
	}
	
	/**
	 * The amount of coproduct will be the percentage to produce 10mb.
	 * */
	public void addCoProduct(Fluid fluid, FluidStack coproduct)
	{
		copr.put(Integer.valueOf(fluid.getID()), coproduct);
	}
	
	public ItemStack getCasted(FluidStack fluid)
	{
		return (ItemStack) casting.get(fluid.getFluid().getID());
	}
	
	public boolean hasCoProduct(FluidStack fluid)
	{
		return copr.containsKey(fluid.getFluid().getID());
	}
	
	public FluidStack getCoProduct(FluidStack fluid)
	{
		return (FluidStack) copr.get(fluid.getFluid().getID());
	}
}

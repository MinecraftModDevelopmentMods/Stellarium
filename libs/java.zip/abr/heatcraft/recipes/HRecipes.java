package abr.heatcraft.recipes;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidStack;
import abr.heatcraft.block.HBlocks;
import abr.heatcraft.fluid.HFluids;
import abr.heatcraft.item.HItems;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.ShapedOreRecipe;

public class HRecipes {
	public static void Init(){
		GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(HItems.heatplate, 1),
				"x", "y", "x",
				'x', "ingotIron",
				'y', "dustRedstone"));
		GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(HItems.heatplate, 1),
				"x", "z", "x",
				'x', "ingotIron",
				'z', "ingotCopper"));
		GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(HItems.heatplate, 1),
				"x", "z", "x",
				'x', "ingotLead",
				'z', "ingotCopper"));
		
		GameRegistry.addRecipe(new ItemStack(HBlocks.heatBlock),
				"xxx", "xxx", "xxx",
				'x', new ItemStack(HItems.heatplate));
		GameRegistry.addRecipe(new ItemStack(HBlocks.heatCauldron),
				"x x", "x x", "xxx", 'x', new ItemStack(HItems.heatplate));
		GameRegistry.addRecipe(new ItemStack(HBlocks.heatFurnaceidle),
				"xxx", "x x", "xyx",
				'x', new ItemStack(HItems.heatplate),
				'y', new ItemStack(Blocks.stone_slab, 1, 4));
		
		GameRegistry.addRecipe(new ItemStack(HItems.box),
				" x ", "x x", " x ", 'x', new ItemStack(HItems.heatplate));
		GameRegistry.addShapelessRecipe(new ItemStack(HItems.boxlava),
				new ItemStack(HItems.box),
				new ItemStack(Items.lava_bucket));
		GameRegistry.addRecipe(new ItemStack(HItems.fuelprogress),
				" x ", "xzx", "xyx",
				'x', new ItemStack(HItems.heatplate),
				'y', new ItemStack(Blocks.stone_slab, 1, 4),
				'z', new ItemStack(Blocks.redstone_lamp));
		GameRegistry.addRecipe(new ItemStack(HItems.cookprogress),
				"xxx", "xyx", " x ",
				'x', new ItemStack(HItems.heatplate),
				'y', new ItemStack(Blocks.redstone_lamp));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.liqtank),
				"yxy", "x x", "yxy",
				'x', new ItemStack(HItems.heatplate),
				'y', new ItemStack(Items.feather));
		GameRegistry.addShapelessRecipe(new ItemStack(HItems.fluidprogress),
				new ItemStack(HItems.liqtank), 
				new ItemStack(HItems.box));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.casting),
				"yxy", "x x", "y y",
				'x', new ItemStack(HItems.heatplate),
				'y', new ItemStack(Items.feather));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.bag),
				"zyz", "yxy", "zyz",
				'x', new ItemStack(HItems.box),
				'y', new ItemStack(Items.leather),
				'z', new ItemStack(HItems.heatplate));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.exbag),
				"zyz", "yxy", "zyz",
				'x', new ItemStack(HItems.bag),
				'y', new ItemStack(Items.leather),
				'z', new ItemStack(HItems.heatplate));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.filler),
				" h ", "yxy", " z ",
				'x', new ItemStack(HItems.liqtank),
				'y', new ItemStack(Items.feather),
				'z', new ItemStack(HItems.heatplate),
				'h', new ItemStack(Blocks.hopper));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.drain),
				" z ", "yxy", " h ",
				'x', new ItemStack(HItems.liqtank),
				'y', new ItemStack(Items.feather),
				'z', new ItemStack(HItems.heatplate),
				'h', new ItemStack(Blocks.hopper));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.fluidmover, 1, 3),
				" z ", "yxy", " z ",
				'x', new ItemStack(HItems.liqtank),
				'y', new ItemStack(Items.feather),
				'z', new ItemStack(HItems.heatplate));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.itemmover, 1, 3),
				"zzz", "y y", "zzz",
				'y', new ItemStack(Items.feather),
				'z', new ItemStack(HItems.heatplate));
		GameRegistry.addShapedRecipe(new ItemStack(HItems.crafter),
				" z ", "yxy", " z ",
				'x', new ItemStack(Blocks.crafting_table),
				'y', new ItemStack(Items.feather),
				'z', new ItemStack(HItems.heatplate));
		
		for(int i = 0; i < 4; i++)
		{
			GameRegistry.addShapelessRecipe(new ItemStack(HItems.fluidmover, 1, (i+1)%4),
					new ItemStack(HItems.fluidmover, 1, i));
			GameRegistry.addShapelessRecipe(new ItemStack(HItems.itemmover, 1, (i+1)%4),
					new ItemStack(HItems.itemmover, 1, i));
		}
		
		Fluid reg, reg2;
		
		if(FluidRegistry.isFluidRegistered("steam"))
		{
			reg = FluidRegistry.getFluid("steam");
			FluidHeatRecipes.heating().addFluidHeating("water", reg, 1000);
		}
		
		reg = FluidRegistry.getFluid("lava");
		FluidHeatRecipes.heating().addItemHeating(Item.getItemFromBlock(Blocks.stone),
				new FluidStack(reg, 1000), 30000);
		FluidHeatRecipes.heating().addItemHeating(Item.getItemFromBlock(Blocks.cobblestone),
				new FluidStack(reg, 1000), 28000);
		
		
		reg = FluidRegistry.getFluid("liqorecopper");
		reg2 = FluidRegistry.getFluid("liqgold");
		FluidHeatRecipes.heating().addOreHeating("oreCopper", new FluidStack(reg, 2000), 1000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.copper_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 5));

		reg = FluidRegistry.getFluid("liqoretin");
		reg2 = FluidRegistry.getFluid("liqiron");
		FluidHeatRecipes.heating().addOreHeating("oreTin", new FluidStack(reg, 2000), 1000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.tin_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 15));
		
		reg = FluidRegistry.getFluid("liqoreiron");
		reg2 = FluidRegistry.getFluid("liqlead");
		FluidHeatRecipes.heating().addOreHeating("oreIron", new FluidStack(reg, 2000), 1000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(Items.iron_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 15));
		
		reg = FluidRegistry.getFluid("liqoregold");
		reg2 = FluidRegistry.getFluid("liqsilver");
		FluidHeatRecipes.heating().addOreHeating("oreGold", new FluidStack(reg, 2000), 1000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(Items.gold_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 25));
		
		reg = FluidRegistry.getFluid("liqoresilver");
		reg2 = FluidRegistry.getFluid("liqtin");
		FluidHeatRecipes.heating().addOreHeating("oreSilver", new FluidStack(reg, 2000), 1000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.silver_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 20));

		reg = FluidRegistry.getFluid("liqorelead");
		reg2 = FluidRegistry.getFluid("liqcopper");
		FluidHeatRecipes.heating().addOreHeating("oreLead", new FluidStack(reg, 2000), 2000);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.lead_ingot));
		CastingRecipes.instance().addCoProduct(reg, new FluidStack(reg2, 10));

		
		reg = FluidRegistry.getFluid("liqcopper");
		FluidHeatRecipes.heating().addOreHeating("ingotCopper", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.copper_ingot));

		reg = FluidRegistry.getFluid("liqtin");
		FluidHeatRecipes.heating().addOreHeating("ingotTin", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.tin_ingot));
		
		reg = FluidRegistry.getFluid("liqiron");
		FluidHeatRecipes.heating().addOreHeating("ingotIron", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(Items.iron_ingot));
		
		reg = FluidRegistry.getFluid("liqgold");
		FluidHeatRecipes.heating().addOreHeating("ingotGold", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(Items.gold_ingot));
		
		reg = FluidRegistry.getFluid("liqsilver");
		FluidHeatRecipes.heating().addOreHeating("ingotSilver", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.silver_ingot));

		reg = FluidRegistry.getFluid("liqlead");
		FluidHeatRecipes.heating().addOreHeating("ingotLead", new FluidStack(reg, 1000), 300);
		CastingRecipes.instance().addCasting(reg, new ItemStack(HItems.lead_ingot));


	}
}

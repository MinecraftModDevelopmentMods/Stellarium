package abr.heatcraft.block;

import net.minecraft.block.material.Material;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;

public class BlockOreFluid extends BlockFluidClassic {

	public BlockOreFluid(Fluid fluid, Material material) {
		super(fluid, material);
	}
}
